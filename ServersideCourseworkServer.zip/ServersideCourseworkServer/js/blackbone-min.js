https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js

https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js

https://cdnjs.cloudflare.com/ajax/libs/backbone.js/1.2.3/backbone-min.js