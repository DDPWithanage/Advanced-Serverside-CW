<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Edit Answers</title>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.5.2/underscore-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/backbone.js/1.0.0/backbone-min.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>

<div class="container">
	<h1>Edit your Answers</h1><br>
	<form>

	<?php
         foreach ($names as $value) {
			
        ?>
		
	<div class="form-group">
		<label for='AnswerDescrption'> Answer Description </label>
   		<input type="text" class="form-control" name="answer_Description" id="answer_Description" placeholder= '<?=$value->answer_Description?>'><br>
	</div>
	
		<input type="submit" class="btn btn-primary" value="Edit Answers" id="editAnswers"/>
	<?php 	
}
	 ?>  

    	
	</form>
<div>
    <script>
  
  $(document).ready(function() {
	$("#editAnswers").click(function(event) {
		  event.preventDefault();
		var answer_Description = $("input#answer_Description").val(); 

	$.ajax({
		method: "POST",
		url: "<?php echo base_url(); ?>index.php/ViewAnswers/editAnswer/<?=$value->answer_Id?>",
		dataType: 'JSON',
		data: {answer_Id: answer_Id, answer_Description: answer_Description},
		
		success: function(data) {
			window.location.href = '/HomeController/loadData';
			console.log("Success");
			
		}
	});

	clearfields();
	  });
  });

  function clearfields()
	{
		$('#answer_Description').val('');
	}

	$(document).ready(function() {
	  event.preventDefault();
	$.ajax({
		method: "POST",
    	url: "<?php echo base_url(); ?>index.php/PostAnswers/getAnswers/<?=$value->answer_Id?>",	
		dataType: 'JSON',
		data: {answer_Id: answer_Id, answer_Description: answer_Description},
		
		success: function(data) {
			console.log(questionId, question_Title, question_Description);
			$("#data").load(location.href + " #data"); 
            $("input#answer_Description").val("");  
		}
	});
	
  });

  </script>

</body>
</html>