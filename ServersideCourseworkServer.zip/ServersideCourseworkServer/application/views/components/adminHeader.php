<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

  <link rel="stylesheet" href="<?php echo base_url(); ?>/css/adminHeader.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
    body { padding-top: 70px; }
  </style>
  
</head>

<nav class="navbar navbar-light navbar-fixed-top" style="background-color: #000033;">
  <div class="container-fluid">
    <div class="navbar-header">
        <a href="#" class="navbar-left"><img src="../images/logo.jpg" style="width:45px; height:45px;"></a>
      </div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo site_url('/HomeController/loadData') ?>">Home</a></li>
        <li><a href="<?php echo site_url('/Signup'); ?>">Signup</a></li>
        <li><a href="<?php echo site_url('/Login') ?>">Login</a></li>
      </ul>
      <form class="navbar-form navbar-right" role="search">
      <ul class="nav navbar-nav">
        <a class="nav-link" href="<?php echo site_url('/HelpController') ?>">Contact Us</a>
        <a class="nav-link" href="<?php echo site_url('/Login/logout') ?>">Log out</a>
      </ul>
      </form>
    </div>
</nav>

<body>
<footer class="footer" style="background-color:#e3f2fd;">
<div class="d-flex flex-column flex-md-row text-center text-md-start justify-content-between py-4 px-4 px-xl-5 bg-primary">
    <!-- Copyright -->
    <div class="text-white mb-3 mb-md-0">
      Copyright © 2020. All rights reserved.
    </div>
    <!-- Copyright -->

    <!-- Right -->
    <div>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-facebook-f"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="#!" class="text-white me-4">
        <i class="fab fa-google"></i>
      </a>
      <a href="#!" class="text-white">
        <i class="fab fa-linkedin-in"></i>
      </a>
    </div>
    <!-- Right -->
  </div>
</footer>

</body>
</html>