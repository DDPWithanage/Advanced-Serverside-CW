<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<style>
  body {
    margin: 0;
    font-family: "Lato", sans-serif;
  }
  
  .sidebar{
    position: fixed;
    left: 0;
    bottom: 0;
    height: 94%;
    background-color: #000033;
    text-align: center;
    max-width: 180px;
    margin-top: 0px;

  }
  .sidebar a {
    display: block;
    color: white;
    padding: 16px;
    text-decoration: none;
  }
   
  .sidebar a.active {
    background-color: white;
    color: white;
  }
  
  .sidebar a:hover:not(.active) {
    background-color: #80aaff;
    color: white;
  }
  .btn{
    background-color:#b3b3ff; 
    border-radius: 25px;
    margin: 0 0 0 0;
    align-items: center;
    color:black;
  }
  .logout{
    position: absolute;
    bottom: 0px;
    margin-left:25px;
  }
  
  
</style>

</head>

<body>
    <div class="sidebar">

      <a href="<?php echo site_url('/HomeController/loadData') ?>">Home</a>
      <a href="<?php echo site_url('/Signup'); ?>">Signup</a>
      <a href="<?php echo site_url('/Login') ?>">Login</a>
      <a class="nav-link" href="<?php echo site_url('/HelpController') ?>">Contact Us</a>


      <a href="<?php echo site_url('/PostQuestions') ?>">
      <button type="button" class="btn" id="addQuestions">Post Questions </button></a><br>

      <!-- <a href="<?php echo site_url('/postAnswers') ?>">
      <button type="button" class="btn" id="addAnswers">Post Answers </button></a><br><br><br> -->

      <div class = "logout">
        <a class="nav-link" href="<?php echo site_url('/Login/logout') ?>">Log out</a>
    </div>
  </div>
</body>
</html>
