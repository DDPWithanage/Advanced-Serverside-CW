<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Admin</title>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.5.2/underscore-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/backbone.js/1.0.0/backbone-min.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

	<script>
		tinymce.init({
			selector: 'textarea#editor',
			skin: 'bootstrap',
			plugins: 'lists, link, image, media',
			toolbar: 'h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help',
			menubar: false,
		});
	</script>

</head>
<body>

<div class="container">
	<h1>Post Questions</h1><br>

	<?php echo form_open('PostQuestions/createQuestions'); ?>
   
		<div class="form-group">
			<label for="QuestionTitle"> Question Title </label>
			<input type="text" class="form-control" name="question_Title" id="question_Title" placeholder="Question Title"/>
		</div>
			
		<div class="row justify-content-md-center">
			<div class="col-md-12 col-lg-8">
				
				<label>Question Description</label>
				<div class="form-group">
					<textarea id="editor" class="form-control" name="question_Description" id="question_Description" style="color: black"></textarea>
				</div>
				<input type="submit" class="btn btn-primary" value="Add Questions" id="addQuestions"/>
			</div>
		</div>

	</form>

<div>
   
   
  <script>
  
  var PostQuestionsView = Backbone.View.extend({
    el: '#postQuestions-form', // The element that this view should be bound to

    events: {
        'submit': 'submit' // Bind the submit event to the 'submit' function
    },

	submit: function(event) {
		event.preventDefault();
	
			// Get the form data
			var data = {
				// user_Id: this.$el.find('input[name=user_Id]').val(),
				question_Title: this.$el.find('input[name=question_Title]').val(),
				question_Description: this.$el.find('input[name=question_Description]').val()
        	};

		$.ajax({
			method: "POST",
			url: "PostQuestions/createQuestions",	
			dataType: 'JSON',
			data: data,
			
			success: function(data) {
					//Redirect to the login page if the sign Up page successfully submitted.
					window.location.href = '/answerPage';	
				},
				error: function(xhr, status, error) {
					//Display an error message 
					alert(error);
				}
		});

		clearfields();
	  }
  });

  function clearfields()
	{
		$('#question_Title').val('');
		$('#question_Description').val('');
	}


	// Create a new instance of the postQuestionsView
	var postQuestionsView = new PostQuestionsView();

  </script>

</div>

</body>
</html>