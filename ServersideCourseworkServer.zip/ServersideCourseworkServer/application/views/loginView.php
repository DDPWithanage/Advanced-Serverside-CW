<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

  <link rel="stylesheet" href="../css/login.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.5.2/underscore-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/backbone.js/1.0.0/backbone-min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <style>
     /* #confirm {
      display: none;
      background-color: #F3F5F6;
      color: #000000;
      border: 1px solid #aaa;
      position: fixed;
      width: 300px;
      height: 100px;
      left: 40%;
      top: 40%;
      box-sizing: border-box;
      text-align: center;
    }
    #confirm button {
      background-color: #FFFFFF;
      display: inline-block;
      border-radius: 12px;
      border: 4px solid #aaa;
      padding: 5px;
      text-align: center;
      width: 60px;
      cursor: pointer;
    } 
    #confirm .message {
      text-align: left;
    } */
/* 
    .alert-box{
    background-color: #d4edda;
    color: #155724;
    border-color: #c3e6cb;
    padding: 20px;
    text-align: center;
  } */
	.alert {
		position: relative;
		padding: 0rem 1.25rem 0rem 1.25rem;
		margin-bottom: 1rem;
		border: 0px solid transparent;
		border-radius: .25rem;
	}
    </style>

</head>
<body>
<section class = "Form my-4 mx-5">
  <div class="container">
    <div class= "row row-no-gutters">
      <div class = "col-lg-5">
				<img src = "../images/login.jpg" class= "img-fluid" alt="" style="width:470px; height:500px;">
			</div>
      <div class = "col-lg-7 px-5 pt-5">
				<h1 class= "font-weight-bold py-3">Login</h1>

      <!-- Display validation errors, if any -->
      <div class="alert alert-danger" role="alert">
        <?php echo validation_errors(); ?>
        <!-- Display login error, if any -->
        <?php if (isset($error_message)) { echo $error_message; } ?>
      </div>

        <!-- Login form -->
        <?php echo form_open('Login/loginValidation');?>

          <div class="form-row">
            <div class = "col-lg-10">
              <label for="Email"> Email </label>
              <input type="email" class="form-control" name="user_EmailAddress" id="user_EmailAddress" placeholder="Email Address"><br>
            </div>
          </div>
              
          <div class="form-row">
            <div class = "col-lg-10">
              <label for="Password"> Password </label>
              <input type="password" class="form-control" name="user_Password" id="user_Password" placeholder="Password"/><br><br>
            </div>
          </div>
              
          <div class="form-row">
            <div class = "col-lg-10">
            <input type="submit" class="btn1" value="Login" id="loginPage"/><br><br>
            </div>
          </div>

          <div class="form-row">
            <div class = "col-lg-10">
              <p>Don't have an account? <a href="#">Register here</a></p>
            </div>
          </div>

        </form>
      </div>
    </div>
<!-- 
    <div id="alert-box"></div> -->
  </div>

</section>



  <script>

  var LoginView = Backbone.View.extend({
    el: '#login-form', // The element that this view should be bound to

    events: {
        'submit': 'submit' // Bind the submit event to the 'submit' function
    },

    submit: function(event) {
		  event.preventDefault();
          
      var data = {
            email: this.$el.find('input[name=user_EmailAddress]').val(),
            password: this.$el.find('input[name=user_Password]').val()
      };

    $.ajax({
      method: "POST",
      url: "Login/loginValidation",	
      dataType: 'JSON',
      data: data,

      success: function(response) {
                // The form submission was successful, redirect to the home page
               // loginAlert(msg, gfg)
               // window.location.href = '/HomeController/loadData';

                

            },
            error: function(xhr, status, error) {
                // The form submission failed, display the error message
                window.location.href = '/Login';
                alert(error);
            }
        });

        clearfields();
        }
      });
  
    //   function loginAlert(msg, myYes) {
    //     var confirmBox = $("#confirm");
    //         confirmBox.find(".message").text(msg);
    //         confirmBox.find(".yes").unbind().click(function() {
    //            confirmBox.hide();
    //         });
    //         confirmBox.find(".yes").click(myYes);
    //         confirmBox.show();
    // }

  function clearfields()
	{
		$('#user_EmailAddress').val('');
		$('#user_Password').val('');
	}

  // Create a new instance of the LoginView
  var loginView = new LoginView();

//   $(document).ready(function(){
//   $("#loginPage").click(function(){
//     $("#alert-box").html("<div class='alert-box'>Login Successful!</div>");
//     setTimeout(function(){
//       window.location.href ='/HomeController/loadData';
//     }, 2000);
//   });
// });

  </script>

</div>


<!-- <div id="confirm">
  <div class="message">This is a warning message.</div><br>
  <button class="yes">OK</button>
</div> -->


</body>
</html>