<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ViewAnswers extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('AnswersModel');
		$this->load->view('components/header');
		$this->load->view('components/sidebar');

	}

	// public function getQuestionId($ques_Id){
	// 	$this->load->model('AnswersModel');
    //     $result= $this->data['ids'] = $this->AnswersModel->getQuestionId($ques_Id);
	// 	echo $result;
	// 	$this->load->view('answersView',$this->data);
	// }

	//display answers in the system
	public function displayAnswers($id)
	{
		$this->load->model('AnswersModel');
        $result= $this->data['names'] = $this->AnswersModel->getAnswerbyQuestionId($id);
		$this->load->view('answersView',$this->data, 'refresh');
	}
	
	//delete answers
	public function deleteRecords($id){
		$this->load->model('AnswersModel');
		$this->AnswersModel->deleteAnswers($id);
		return true;
	}

	//up  vote 
	public function upvote($answerId) {
		$vote = $this->session->vote;
		$this->load->model('AuthModel');
		$this->load->model('AnswersModel');
		$response = $this->AnswersModel->upVoteAnswer($answerId);
		$this->load->view('answersView',$this->data);
	}

	//down  vote 
	public function downvote($answerId) {
		$vote = $this->session->vote;
		$this->load->model('AuthModel');
		$response = $this->AnswersModel->downVoteAnswer($answerId);
		$this->load->view('answersView',$this->data);
	}	

	// //display questions
	// public function fetchAnswers($answerId){
	// 	$this->load->model('AnswersModel');
	// 	$this->data['answers'] = $this->AnswersModel->getAnswersById($answerId);
	// 	$this->load->view('components/header');
	// 	$this->load->view('editAnswers',$this->data);
	// }

	// //update questions function
	// public function editAnswer($questionId){
	// 	$this->load->view('components/header');
	// 		$answerId = $this->input->post('answer_Id');
	// 		$questionId = $this->session->question_Id;
	// 		$answerDescription = $this->input->post('answer_Description');
	// 		$upVote = $this->input->post('up_Vote');
	// 		$downVote = $this->input->post('down_Vote');
	// 		$data['answers'] = $this->AnswersModel->updateAnswers($answerId,$questionId,$answerDescription, $upVote, $downVote);
	// 		$this->load->view('editAnswers');
	// }

	//update answers 
	public function editAnswer($answerId){
		$this->load->model('AnswersModel');
		$answer = $this->input->post('answer');
		$data['names'] = $this->AnswersModel->updateAnswers($answerId,$answer);
		$this->load->view('editAnswers');
}

	// public function deleteRecords($answer_id) {
	// 	$username = $this->session->username;
	// 	if($this->AuthModel->is_loggedin() == true) {
	// 		$response = $this->AuthModel->deleteAnswers($answer_id, $username);
	// 		if(!$response) {
	// 			$this->set_response($response, \Restserver\Libraries\REST_Controller::HTTP_NO_CONTENT);
	// 		} else {
	// 			$res = "200 OK";
	// 			$this->set_response($res, \Restserver\Libraries\REST_Controller::HTTP_OK); // CREATED (201) being the HTTP response code
	// 		}
	// 	} else {
	// 		$res = "401 Unauthorized";	
	// 		$this->set_response($res, \Restserver\Libraries\REST_Controller::HTTP_UNAUTHORIZED); // CREATED (401) unauthorized to access the requested resource
	// 	}	
	// }
			
}