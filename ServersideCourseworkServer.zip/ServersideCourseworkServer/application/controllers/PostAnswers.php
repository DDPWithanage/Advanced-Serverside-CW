<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PostAnswers extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('AnswersModel');
	}

	public function index()
	{
		$this->load->view('./components/header');
		$this->load->model('AnswersModel');
		$this->load->view('postAnswersView');
	}

	// //create answers
	// public function createAnswers() {
	// 	$question_Id = $this->session->question_Id;
	// 	if ($this->input->server('REQUEST_METHOD') == 'POST') {
			
	// 		// $question_Id = $this->input->post('question_Id');
	// 		$answer_Description = $this->input->post('answer_Description');
	// 		$up_Vote = $this->input->post('up_Vote');
	// 		$down_Vote = $this->input->post('down_Vote');
			
	// 		$data = $this->AnswersModel->insertAnswers($question_Id, $answer_Description, $up_Vote, $down_Vote);
	// 		echo json_encode($data);
	// 		redirect('ViewAnswer/displayAnswers');
	// 	}	
	// }

	//create answers
	public function createAnswers() {
		$question_Id = $this->session->question_Id;
		if ($this->input->server('REQUEST_METHOD') == 'POST') {
			
			$question_Id = $this->input->post('question_Id');
			$answer_Description = $this->input->post('answer_Description');
			
			$data = $this->AnswersModel->insertAnswers($question_Id, $answer_Description);
			echo json_encode($data);
			redirect('ViewAnswers/displayAnswers/');
		}	
	}

	// public function postAnswer($quetionId) {
	// 	$email = $this->session->user_EmailAddress;
	// 	$this->load->model('AuthModel');
	// 	$this->load->view('PostAnswersView');
	// 	if ($this->input->server('REQUEST_METHOD') == 'POST') {
	// 		$answer = $this->input->post('answer');
	// 		$questionId =2;
	// 		$this->load->model('Usermodel');
	// 		if($this->Usermodel->is_logged_in() == true) {
	// 		$data = $this->Answermodel->addAnswers($email, $questionId,$answer);
	// 		$this->load->view('Postanswer_view',$this->data);
	// 		echo json_encode($data);
	// 		}else{
				
	// 				echo "login failed";
				
	// 		}
	// 	}

	// }

	//get answers from the database
	public function getAnswers($answerId){
		$this->load->model('AnswersModel');
		$this->data['names'] = $this->AnswersModel->getAnswersById($answerId);
		$this->load->view('components/header');
		$this->load->view('editAnswers',$this->data);
	}

	//up vote functions
	public function upvote($answer_Id) {
		$vote = $this->session->vote;
		$this->load->model('AuthModel');
		if($this->AuthModel->is_logged_in() == true) {
			$response = $this->AnswersModel->upVoteAnswers($answer_Id);
			$this->load->view('components/header');
			
			if(!$response) {
				$res = "204 HTTP_NO_CONTENT";

			} else {
				$res = "201 HTTP CREATED";
				
			}
		} else {
		$res = "401 Unauthorized";	
		
		}	
	}

	//down vote functions
	public function downvote($answer_Id) {
		$vote = $this->session->vote;
		$this->load->model('AuthModel');
		if($this->AuthModel->is_logged_in() == true) {
			$response = $this->AnswersModel->downVoteAnswers($answer_Id);
			$this->load->view('components/header');
			if(!$response) {
				$res = "204 HTTP_NO_CONTENT";

			} else {
				$res = "201 HTTP CREATED";
				
			}
		} else {
		$res = "401 Unauthorized";	

		}	

	}
	
}