<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
use Restserver\Libraries\REST_Controller;
require APPPATH . '/libraries/REST_Controller.php';

class HomeController extends CI_Controller {
	
	function __construct() {
		parent::__construct();
		$this->load->database();
		$this->load->model('QuestionsModel');
		$this->load->model('AuthModel');
	}

	public function index(){
		$this->load->view('homePage.php');
		
	}
	
	//load questions
	public function loadData(){
		$this->load->view('components/header');
		$this->load->view('components/sidebar');
		$this->data['names'] = $this->QuestionsModel->displayQuestions();
		$this->load->view('homePage', $this->data);
		
	}

	public function displayLoadData(){
		$this->data['details'] = $this->AuthModel->userDetails();
		$this->load->view('homePage', $this->data);
		
	}

	//delete questions
	public function deleteRecords($id){
		$this->load->model('QuestionsModel');
		$this->QuestionsModel->deleteQuestions($id);
		return true;
	}

	//display questions
	public function getQuestion($questionId){
		$this->load->model('QuestionsModel');
		$this->data['questions'] = $this->QuestionsModel->getQuestionsById($questionId);
		$this->load->view('components/header');
		$this->load->view('editQuestions',$this->data);
	}

	//update questions function
	public function editQuestion($questionId){
		$this->load->view('components/header');
			$useremail = $this->session->user_EmailAddress;
	    	$questionTitle = $this->input->post('question_Title');
			$questionDescription = $this->input->post('question_Description');
			$data['questions'] = $this->QuestionsModel->updateQuestion($useremail,$questionId, $questionTitle, $questionDescription);
			$this->load->view('editQuestions');
			redirect('HomeController/loadData');
	}
	
	// public function deleteRecords($question_id) {
	// 	$username = $this->session->username;
	// 	if($this->AuthModel->is_loggedin() == true) {
	// 		$response = $this->QuestionsModel->deleteQuestions($question_id, $username);
	// 		if(!$response) {
	// 			$this->set_response($response, \Restserver\Libraries\REST_Controller::HTTP_NO_CONTENT);
	// 		} else {
	// 			$res = "200 OK";
	// 			$this->set_response($res, \Restserver\Libraries\REST_Controller::HTTP_OK); // CREATED (201) being the HTTP response code
	// 		}
	// 	} else {
	// 		$res = "401 Unauthorized";	
	// 		$this->set_response($res, \Restserver\Libraries\REST_Controller::HTTP_UNAUTHORIZED); // CREATED (401) unauthorized to access the requested resource
	// 	}	
	// }

//search questions function
public function search() {
	$keywords = $this->input->post('keywords');
	$this->load->model('QuestionsModel');
	$data['results'] = $this->QuestionsModel->searchQuestion($keywords);
	$this->load->view('searchContents', $data);
}
	
}