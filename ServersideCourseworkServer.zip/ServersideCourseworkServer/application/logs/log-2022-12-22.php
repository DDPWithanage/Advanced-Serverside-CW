<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-22 03:52:56 --> 404 Page Not Found: Price/index
ERROR - 2022-12-22 03:53:00 --> 404 Page Not Found: Disable/index
ERROR - 2022-12-22 04:07:02 --> 404 Page Not Found: Price/index
ERROR - 2022-12-22 04:08:01 --> 404 Page Not Found: Price/index
ERROR - 2022-12-22 04:09:54 --> 404 Page Not Found: Price/index
ERROR - 2022-12-22 04:09:58 --> 404 Page Not Found: Disable/index
ERROR - 2022-12-22 04:10:05 --> 404 Page Not Found: Price/index
ERROR - 2022-12-22 04:10:45 --> 404 Page Not Found: Price/index
ERROR - 2022-12-22 06:17:38 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 20
ERROR - 2022-12-22 06:17:38 --> Severity: Warning --> log() expects parameter 1 to be double, array given C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 20
ERROR - 2022-12-22 06:18:08 --> Severity: Error --> Call to undefined function eecho() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 20
ERROR - 2022-12-22 06:18:24 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 20
ERROR - 2022-12-22 06:19:56 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 20
ERROR - 2022-12-22 06:20:26 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 20
ERROR - 2022-12-22 06:31:08 --> 404 Page Not Found: Question/index
ERROR - 2022-12-22 06:34:01 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`question`, CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_Id`) REFERENCES `user` (`user_Id`)) - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('', '', '')
ERROR - 2022-12-22 06:34:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`question`, CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_Id`) REFERENCES `user` (`user_Id`)) - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('', '', '')
ERROR - 2022-12-22 06:34:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`question`, CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_Id`) REFERENCES `user` (`user_Id`)) - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('', '', '')
ERROR - 2022-12-22 06:53:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`question`, CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_Id`) REFERENCES `user` (`user_Id`)) - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('', '', '')
ERROR - 2022-12-22 06:55:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`question`, CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_Id`) REFERENCES `user` (`user_Id`)) - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('', '', '')
ERROR - 2022-12-22 07:05:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`question`, CONSTRAINT `question_ibfk_1` FOREIGN KEY (`user_Id`) REFERENCES `user` (`user_Id`)) - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('', '', '')
ERROR - 2022-12-22 07:35:04 --> 404 Page Not Found: PostAnswers/index
ERROR - 2022-12-22 07:47:31 --> 404 Page Not Found: PostAnswers/index
ERROR - 2022-12-22 07:50:21 --> 404 Page Not Found: PostAnswers/index
ERROR - 2022-12-22 07:50:25 --> 404 Page Not Found: PostAnswers/index
ERROR - 2022-12-22 08:15:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-22 08:25:58 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-22 09:43:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:43:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:54:30 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:54:30 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:54:32 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:54:32 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:54:50 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:54:50 --> Severity: Notice --> Undefined variable: result C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:58:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:58:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:59:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 09:59:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 10:00:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 10:00:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 10:04:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 10:04:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 12:20:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 12:20:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:38:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:38:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:39:01 --> 404 Page Not Found: ViewAnswers/loadData
ERROR - 2022-12-22 14:43:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:43:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:44:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:44:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:45:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:45:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:46:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 14:46:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:06:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:06:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:08:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:08:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:09:51 --> Severity: Error --> Call to undefined method CI_Loader::function() C:\xampp\htdocs\Serverside_coursework\application\controllers\postAnswers.php 14
ERROR - 2022-12-22 15:10:11 --> Severity: Error --> Call to undefined method CI_Loader::function() C:\xampp\htdocs\Serverside_coursework\application\controllers\postAnswers.php 14
ERROR - 2022-12-22 15:11:00 --> Severity: Error --> Call to undefined method CI_Loader::function() C:\xampp\htdocs\Serverside_coursework\application\controllers\postAnswers.php 14
ERROR - 2022-12-22 15:11:02 --> Severity: Error --> Call to undefined method CI_Loader::function() C:\xampp\htdocs\Serverside_coursework\application\controllers\postAnswers.php 14
ERROR - 2022-12-22 15:11:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:11:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:12:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-22 15:12:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:12:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:12:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2022-12-22 15:12:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
