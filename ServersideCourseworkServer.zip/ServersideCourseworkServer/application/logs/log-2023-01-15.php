<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-15 03:01:14 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:01:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:01:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:01:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-15 03:01:18 --> Severity: Error --> Call to undefined function alert() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 57
ERROR - 2023-01-15 03:02:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:02:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:02:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-15 03:02:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 58
ERROR - 2023-01-15 03:04:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 59
ERROR - 2023-01-15 03:04:09 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 59
ERROR - 2023-01-15 03:04:11 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 59
ERROR - 2023-01-15 03:04:16 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 59
ERROR - 2023-01-15 03:04:28 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:04:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:04:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:04:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-15 03:04:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 59
ERROR - 2023-01-15 03:27:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:27:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:27:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:27:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:27:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:27:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:27:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:27:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:27:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:27:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:27:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:27:19 --> Severity: Notice --> Undefined variable: keywords C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 61
ERROR - 2023-01-15 03:27:19 --> Severity: Notice --> Undefined variable: keywords C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 62
ERROR - 2023-01-15 03:27:19 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:27:19 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:27:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:28:17 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:28:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:28:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:28:19 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:28:19 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:28:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:28:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:28:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:28:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:28:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:28:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:28:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:28:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:28:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:28:35 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:28:35 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:28:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:28:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:29:29 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:29:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:29:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:29:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:29:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 47
ERROR - 2023-01-15 03:29:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:29:31 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 69
ERROR - 2023-01-15 03:29:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 130
ERROR - 2023-01-15 03:30:19 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:30:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:30:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:30:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 03:30:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:30:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:30:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-15 03:30:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 03:30:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:30:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:30:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-15 03:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-15 03:30:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 03:30:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 03:31:38 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:31:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-15 03:31:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-15 03:31:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 03:31:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 03:33:38 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:33:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:33:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-15 03:33:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-15 03:33:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 03:33:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 03:35:52 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:35:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:35:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 03:35:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 03:35:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 03:35:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 03:35:57 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 04:28:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:28:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:28:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 04:28:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 04:29:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:29:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:29:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 04:29:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 04:29:11 --> Severity: Warning --> Missing argument 1 for HomeController::search() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 60
ERROR - 2023-01-15 04:29:16 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:29:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 04:29:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 04:29:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:29:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 04:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 04:36:39 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:36:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 04:36:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 04:36:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 19:04:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:04:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:04:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:04:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 19:04:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:04:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:04:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:21:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:21:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:21:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:22:14 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:22:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:22:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:22:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 19:22:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:22:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:22:50 --> Query error: Unknown column 'useremail' in 'where clause' - Invalid query: SELECT `user_Id`
FROM `user`
WHERE `useremail` = 'imasha@gmail.com'
ERROR - 2023-01-15 19:25:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:25:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:25:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:25:14 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 19:25:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 19:25:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 20:35:39 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 20:35:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 20:35:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 20:35:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:35:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:35:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:36:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 20:36:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 20:36:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 20:36:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:36:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:40:58 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 20:40:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-15 20:40:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 98
ERROR - 2023-01-15 20:40:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:40:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:51:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:51:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:51:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:51:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:51:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:51:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:51:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:51:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:51:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:51:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:51:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:51:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:52:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:52:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:52:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:52:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:53:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:53:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:53:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:53:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:53:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:53:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:53:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:53:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:53:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:53:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:53:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:53:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:53:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:53:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:53:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:53:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:54:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:54:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:54:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:54:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:54:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:54:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:54:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:54:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:54:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 20:54:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:54:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 20:54:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 20:54:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 20:54:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:00:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 21:00:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 21:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 21:00:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:00:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:00:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:00:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 113
ERROR - 2023-01-15 21:00:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 21:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 133
ERROR - 2023-01-15 21:00:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 112
ERROR - 2023-01-15 21:00:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:00:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:09:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 112
ERROR - 2023-01-15 21:09:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:09:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:09:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:10:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 112
ERROR - 2023-01-15 21:10:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:10:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:10:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:10:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:10:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:10:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 112
ERROR - 2023-01-15 21:10:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:10:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:10:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:10:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:10:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:10:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 112
ERROR - 2023-01-15 21:10:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:10:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:10:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:10:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:10:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:11:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 112
ERROR - 2023-01-15 21:11:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 132
ERROR - 2023-01-15 21:11:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:11:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:14:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:14:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:14:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:14:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:14:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:14:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:14:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:14:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:14:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:14:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:14:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-15 21:14:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-15 21:14:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-15 21:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:14:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:14:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:14:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:14:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:18:51 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-15 21:18:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:18:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:18:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:18:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:18:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:18:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:18:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:18:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:18:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-15 21:18:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 143
ERROR - 2023-01-15 21:19:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 79
ERROR - 2023-01-15 21:19:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 99
ERROR - 2023-01-15 21:19:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:19:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:19:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:23:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:23:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:23:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:23:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:43:52 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-15 21:44:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:44:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:44:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:03 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '11'
ERROR - 2023-01-15 21:44:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:44:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:44:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:06 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '12'
ERROR - 2023-01-15 21:44:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:44:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:44:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:44:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:44:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:26 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-15 21:44:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:44:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:44:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:44:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:44:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:53:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:53:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:53:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:53:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:53:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:53:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:54:39 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-15 21:54:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:54:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:54:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:54:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:54:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:55:28 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-15 21:55:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:55:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:55:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:55:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:55:32 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-15 21:55:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:55:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:55:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:55:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:55:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:55:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:57:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 21:57:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 21:57:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-15 21:57:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 21:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 132
ERROR - 2023-01-15 22:00:43 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '11'
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:00:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:00:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:00:54 --> Severity: Error --> Call to undefined method QuestionsModel::getQuestionbyId() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 39
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:02:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:02:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:02:35 --> Severity: Error --> Call to undefined method QuestionsModel::getQuestionbyId() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 39
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:03:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:03:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:03:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:03:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:03:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:03:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 22:03:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:04:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:04:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:04:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:04:55 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:05:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:05:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:05:51 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:05:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-15 22:05:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-15 22:05:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:09:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:09:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:09:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:09:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:09:36 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:10:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:10:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:10:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:10:03 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT `user_Id`
FROM `user`
WHERE `email` = 'imasha@gmail.com'
ERROR - 2023-01-15 22:35:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:35:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:35:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:35:33 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:35:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:35:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:35:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:35:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:35:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:35:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:38:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:38:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:38:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:38:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:38:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:38:47 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:43:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:43:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:43:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:43:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:43:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:43:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:33 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:43:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:43:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:43:47 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT `user_Id`
FROM `user`
WHERE `email` = 'imasha@gmail.com'
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:51:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:51:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:51:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:51:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:03 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:51:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 22:51:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 22:51:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:51:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:51:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 22:52:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 22:52:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:52:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 22:52:04 --> Query error: Unknown column 'email' in 'where clause' - Invalid query: SELECT `user_Id`
FROM `user`
WHERE `email` = 'imasha@gmail.com'
ERROR - 2023-01-15 23:02:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:02:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:02:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:02:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:02:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:02:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:02:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:02:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:02:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:02:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:02:36 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:02:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:02:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:02:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:03:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:03:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:03:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:03:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:05:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:05:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 23:05:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:05:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:05:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:05:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 23:05:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:05:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:05:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:05:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:05:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:06:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:06:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:06:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:06:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 23:06:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:07:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:07:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:07:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:07:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 23:07:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:09:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:09:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:09:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:09:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 23:09:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:09:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:09:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:09:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:09:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:09:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:09:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:09:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 52
ERROR - 2023-01-15 23:09:15 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:10:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:10:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:10:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:10:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:10:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:10:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:10:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:10:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:10:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:10:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:10:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:10:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:11:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:11:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:11:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:11:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:11:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:11:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:11:26 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:11:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:11:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:11:43 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:11:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:11:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:11:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:13:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:13:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:13:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:13:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:13:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:13:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:13:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:20 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:13:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:13:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:13:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:13:33 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:14:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:14:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:28 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:14:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:14:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:29 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:14:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:14:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:14:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:14:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:14:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:14:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:14:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:14:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:14:53 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:15:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:15:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:15:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:15:23 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:15:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:15:23 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:21:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:21:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:21:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:21:01 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:21:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:21:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:21:40 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:21:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:21:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:21:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:25:01 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 43
ERROR - 2023-01-15 23:25:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:25:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:25:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:25:02 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:25:30 --> Severity: Warning --> sizeof() expects at least 1 parameter, 0 given C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 43
ERROR - 2023-01-15 23:25:30 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 43
ERROR - 2023-01-15 23:25:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:25:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:25:30 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:25:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:25:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:25:50 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:29:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:29:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:29:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:29:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:29:50 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-15 23:29:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-15 23:29:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:29:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:29:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:29:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-15 23:31:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-15 23:31:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-15 23:31:27 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:31:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-15 23:31:27 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-15 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
