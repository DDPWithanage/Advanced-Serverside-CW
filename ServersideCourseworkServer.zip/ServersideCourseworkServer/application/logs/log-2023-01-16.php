<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-16 00:19:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:19:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:19:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:19:01 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 00:19:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 00:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:19:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 00:19:08 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:20:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 00:20:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:23:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 00:23:13 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 00:23:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:23:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:23:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:23:16 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:23:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:23:17 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:23:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:23:17 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 00:23:17 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 00:23:17 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:28:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 00:28:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 12:41:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 12:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:41:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 12:41:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:42:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 12:42:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:44:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 12:44:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 48
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-16 12:55:21 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 13:23:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:23:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:23:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:23:39 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2023-01-16 13:23:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2023-01-16 13:23:39 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 13:23:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:23:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 13:23:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-16 13:25:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:25:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:25:40 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:38:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:38:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:25 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:38:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:38:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:38:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:26 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:38:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 13:38:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:38:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:38:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:38:30 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:38:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 13:39:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:39:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:39:11 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:39:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:39:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:39:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:39:15 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:11 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:13 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 13:40:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:40:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:40:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:16 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 13:40:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 13:40:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:40:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:40:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:40:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:40:23 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:40:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:44:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:44:40 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 82
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:44:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 13:44:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:44:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 13:44:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 13:44:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 13:44:44 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 13:44:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 82
ERROR - 2023-01-16 14:00:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:00:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:00:17 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:00:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:00:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:00:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:00:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:00:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:00:50 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:00:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:00:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:01:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:01:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:02:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:02:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:02:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:02:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:02:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:02:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:22 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:02:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:02:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:02:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:02:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:39 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:02:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:02:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:02:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:02:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:02:41 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:02:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:02:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:03:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:03:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:03:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:03:29 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:03:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:03:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:03:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:03:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:03:56 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:03:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:03:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:03:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:03:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:03:57 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:03:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:04:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:01 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:04:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:04:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:04:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:04:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:04:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:15 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:04:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:16 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:17 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:04:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:04:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:04:57 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 14:04:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:19:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:20:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:20:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:20:38 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:20:38 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:20:38 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:20:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:20:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:37:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 14:37:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:37:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 14:37:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:37:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:37:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:38:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 14:38:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 14:38:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 15:38:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 15:38:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 15:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:51:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 16:51:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 16:51:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 16:51:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 16:51:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:51:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 16:54:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:54:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:55:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:55:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:55:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:55:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 73
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined property: stdClass::$questionId C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 75
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-16 16:55:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:55:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 144
ERROR - 2023-01-16 16:55:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 16:55:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:55:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 16:55:38 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 16:55:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 16:55:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 17:13:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:13:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:13:59 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 17:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 20
ERROR - 2023-01-16 17:13:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 17:17:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:17:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:17:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:17:33 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:17:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:17:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 17:19:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:19:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:19:47 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:19:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:19:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 17:20:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:20:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:20:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:20:00 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:20:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:20:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 17:20:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:20:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:20:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:20:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 17:23:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:23:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:23:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:23:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:23:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-16 17:23:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 17:24:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 17:24:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:24:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 17:24:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 17:24:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 17:24:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:14:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:14:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:14:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:14:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:14:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:14:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:14:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:14:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:14:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:14:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:14:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:14:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:14:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:14:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:14:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:14:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:15:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:15:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:15:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:15:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:15:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:15:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:15:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:15:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:15:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:15:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:15:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:15:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:15:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:15:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:15:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:15:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:15:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:26:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:26:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:26:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:26:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:26:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:26:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:27:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:27:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:27:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:27:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:27:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:27:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:27:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:27:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:27:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:27:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:27:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:27:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:27:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:27:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:27:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:27:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:27:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:28:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:28:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:28:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:28:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:28:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:28:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:28:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:28:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:28:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:28:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-16 19:29:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-16 19:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:29:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:29:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-16 19:29:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-16 19:30:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:30:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-16 19:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-16 19:30:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 19:30:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:30:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-16 19:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-16 19:30:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 57
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-16 19:30:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 52
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-16 19:30:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 52
ERROR - 2023-01-16 19:32:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:32:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:32:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:32:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:34:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:34:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:34:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:34:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:34:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:34:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:34:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:36:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:36:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:36:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:36:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:38:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-16 19:38:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:38:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-16 19:38:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-16 19:38:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-16 19:38:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
