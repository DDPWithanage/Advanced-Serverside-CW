<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-18 18:35:20 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '1234')
ERROR - 2022-12-18 18:35:40 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '1234')
ERROR - 2022-12-18 18:35:46 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '1234')
ERROR - 2022-12-18 18:36:10 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '12344444')
ERROR - 2022-12-18 18:36:29 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '12344444')
ERROR - 2022-12-18 18:38:53 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '12344444')
ERROR - 2022-12-18 18:39:04 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '12344444')
ERROR - 2022-12-18 18:39:05 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi Imasha', 'malmiimasha7@gmail.com', '12344444')
ERROR - 2022-12-18 18:48:37 --> Query error: Unknown column 'name' in 'field list' - Invalid query: INSERT INTO `user` (`name`, `email`, `password`) VALUES ('Malmi', 'malmiimasha7@gmail.com', '890077')
ERROR - 2022-12-18 18:58:02 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '76433578')
ERROR - 2022-12-18 19:02:38 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:39 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:41 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:42 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:42 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:43 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:43 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:45 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:45 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:45 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:47 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:02:48 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', 'uuii765678')
ERROR - 2022-12-18 19:03:17 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:03:18 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:03:18 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:03:18 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:03:18 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:03:22 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:03:22 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, '', '')
ERROR - 2022-12-18 19:04:32 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '234567899')
ERROR - 2022-12-18 19:04:34 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '234567899')
ERROR - 2022-12-18 19:05:42 --> Severity: error --> Exception: Call to undefined method peoplemodel::insertperson() C:\xampp\htdocs\coursework_advancedserverside\application\controllers\people.php 26
ERROR - 2022-12-18 19:05:43 --> Severity: error --> Exception: Call to undefined method peoplemodel::insertperson() C:\xampp\htdocs\coursework_advancedserverside\application\controllers\people.php 26
ERROR - 2022-12-18 19:05:43 --> Severity: error --> Exception: Call to undefined method peoplemodel::insertperson() C:\xampp\htdocs\coursework_advancedserverside\application\controllers\people.php 26
ERROR - 2022-12-18 19:05:43 --> Severity: error --> Exception: Call to undefined method peoplemodel::insertperson() C:\xampp\htdocs\coursework_advancedserverside\application\controllers\people.php 26
ERROR - 2022-12-18 19:09:39 --> 404 Page Not Found: People/person
ERROR - 2022-12-18 19:09:52 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '333333335778')
ERROR - 2022-12-18 19:09:53 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '333333335778')
ERROR - 2022-12-18 19:09:53 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '333333335778')
ERROR - 2022-12-18 19:09:53 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '333333335778')
ERROR - 2022-12-18 19:21:29 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '45673222')
ERROR - 2022-12-18 19:21:31 --> Query error: Column 'username' cannot be null - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES (NULL, 'malmiimasha7@gmail.com', '45673222')
ERROR - 2022-12-18 19:47:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\coursework_advancedserverside\system\core\Loader.php 349
ERROR - 2022-12-18 19:47:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\coursework_advancedserverside\system\core\Loader.php 349
ERROR - 2022-12-18 19:47:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\coursework_advancedserverside\system\core\Loader.php 349
ERROR - 2022-12-18 19:47:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\coursework_advancedserverside\system\core\Loader.php 349
ERROR - 2022-12-18 19:47:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\coursework_advancedserverside\system\core\Loader.php 349
ERROR - 2022-12-18 19:47:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\coursework_advancedserverside\system\core\Loader.php 349
ERROR - 2022-12-18 19:53:58 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:53:58 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:53:59 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:53:59 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:00 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:00 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:00 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:00 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:00 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:00 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:01 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:01 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:01 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:01 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:02 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:03 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:03 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:03 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:03 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:04 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:04 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:06 --> Severity: Warning --> Undefined property: Login::$Auth_model C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:54:06 --> Severity: error --> Exception: Call to a member function auth() on null C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:55:42 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 19:55:43 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 20:00:37 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 20:00:38 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 20:00:39 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 20:00:39 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
ERROR - 2022-12-18 20:00:40 --> Severity: Warning --> Undefined variable $Password C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 30
