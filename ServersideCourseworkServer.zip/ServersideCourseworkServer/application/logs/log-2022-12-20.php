<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-20 09:00:19 --> 404 Page Not Found: People/person
ERROR - 2022-12-20 09:00:46 --> 404 Page Not Found: People/person
ERROR - 2022-12-20 09:06:52 --> 404 Page Not Found: UserDetails/index
ERROR - 2022-12-20 10:46:34 --> 404 Page Not Found: UserDetails/index
ERROR - 2022-12-20 18:22:25 --> Severity: Warning --> Missing argument 1 for viewQuestionsModel::displayQuestions(), called in C:\xampp\htdocs\coursework_advancedserverside\application\controllers\viewQuestions.php on line 14 and defined C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 5
ERROR - 2022-12-20 18:22:25 --> Severity: Warning --> Missing argument 2 for viewQuestionsModel::displayQuestions(), called in C:\xampp\htdocs\coursework_advancedserverside\application\controllers\viewQuestions.php on line 14 and defined C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 5
ERROR - 2022-12-20 18:22:25 --> Severity: Warning --> Missing argument 3 for viewQuestionsModel::displayQuestions(), called in C:\xampp\htdocs\coursework_advancedserverside\application\controllers\viewQuestions.php on line 14 and defined C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 5
ERROR - 2022-12-20 18:22:25 --> Severity: Notice --> Undefined variable: question_Id C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 10
ERROR - 2022-12-20 18:22:25 --> Severity: Notice --> Undefined variable: question_Title C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 10
ERROR - 2022-12-20 18:22:25 --> Severity: Notice --> Undefined variable: question_Description C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 10
ERROR - 2022-12-20 19:34:04 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 14
ERROR - 2022-12-20 19:34:04 --> Severity: Warning --> log() expects parameter 1 to be double, object given C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 14
ERROR - 2022-12-20 19:34:22 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\coursework_advancedserverside\application\models\viewQuestionsModel.php 14
