<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 04:39:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:39:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:45:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:45:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 04:45:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:45:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:45:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:45:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-22 04:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 82
ERROR - 2023-01-22 04:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 82
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 04:45:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:45:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 04:45:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:45:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 04:53:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 04:53:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:53:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 04:53:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 04:53:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 04:53:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 04:53:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:05:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:06:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:06:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:06:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:06:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:07:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:07:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:07:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:07:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:07:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:08:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:08:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:08:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:08:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:08:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:08:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:09:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:09:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:09:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:09:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 05:09:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 05:09:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 05:09:00 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:11:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:11:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:11:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:11:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:12:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:12:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:12:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:12:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:12:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:13:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:13:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:13:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:13:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:13:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:14:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:14:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:14:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:15:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:15:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:15:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:15:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:15:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:15:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:20:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:20:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:20:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:20:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:20:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:20:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:21:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:21:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:23:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:25:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:25:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:25:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:25:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:25:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:26:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-22 05:26:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:26:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:26:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:26:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:27:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:27:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:27:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:27:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:28:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:28:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:28:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:30:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:30:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:30:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:30:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:30:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:32:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:32:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:32:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:32:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:44 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:32:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:32:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:38:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:38:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:38:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:38:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 05:38:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 05:38:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 05:38:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:38:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:38:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:38:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:38:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:38:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:38:17 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-22 05:39:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:40:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:40:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-22 05:40:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-22 05:40:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:40:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:44:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:44:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:44:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:44:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:44:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:44:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:46:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:46:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:46:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:46:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:46:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:46:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:46:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:47:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:47:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:47:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:47:43 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:47:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:49:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:49:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:49:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:49:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:50:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:50:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:50:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:50:22 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:51:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:51:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:51:05 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:51:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:51:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:51:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:51:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:51:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:51:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:51:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:51:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:52:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 05:52:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 05:56:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 05:58:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:58:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 05:58:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 05:58:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:58:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:58:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 05:58:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:02:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:02:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:02:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 06:02:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:21 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 06:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:02:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:02:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:09:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:14:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:14:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-22 06:14:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:14:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:14:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:14:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:14:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:15:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:15:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:15:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:15:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:15:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:15:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:15:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:15:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:15:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:16:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:16:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:16:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:16:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:16:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:17:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:17:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:18:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:18:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:18:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:19:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:19:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-22 06:19:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:19:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-22 06:31:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 06:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-22 06:31:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 06:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:31:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-22 06:31:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 06:31:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 06:34:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 06:34:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:34:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 06:34:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 06:34:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 06:34:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 06:34:05 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 86
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 129
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 129
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 130
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 130
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 131
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 131
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 133
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 133
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 136
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 136
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 140
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 140
ERROR - 2023-01-22 11:22:20 --> Severity: Notice --> Undefined property: CI_Loader::$AnswerModel C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 141
ERROR - 2023-01-22 11:22:20 --> Severity: Error --> Call to a member function getVoteCount() on null C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 141
ERROR - 2023-01-22 11:38:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:38:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:38:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-22 11:38:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-22 11:38:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 56
ERROR - 2023-01-22 11:38:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 91
ERROR - 2023-01-22 11:44:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:44:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 11:44:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 11:44:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-22 11:44:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 11:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 11:44:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:44:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 11:44:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 11:44:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 11:44:44 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 11:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:44:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:44:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-22 11:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-22 11:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 56
ERROR - 2023-01-22 11:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 91
ERROR - 2023-01-22 11:45:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:45:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:45:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-22 11:45:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 22
ERROR - 2023-01-22 11:45:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 56
ERROR - 2023-01-22 11:45:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 91
ERROR - 2023-01-22 11:46:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:46:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:46:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 11:46:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 11:46:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-22 11:46:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 90
ERROR - 2023-01-22 11:46:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:46:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:46:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 11:46:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 11:46:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 11:46:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:46:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:46:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 11:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 11:46:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-22 11:46:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 90
ERROR - 2023-01-22 11:47:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:47:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:47:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 11:47:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 11:47:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 11:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 11:47:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 11:47:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 11:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 11:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-22 11:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 90
ERROR - 2023-01-22 12:11:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 12:11:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 12:11:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 12:11:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 12:11:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 12:11:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-22 12:11:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 90
ERROR - 2023-01-22 13:34:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:34:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:34:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 13:34:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 13:34:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 55
ERROR - 2023-01-22 13:34:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 90
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:44:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 50
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 85
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 128
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 128
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 129
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 129
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 130
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 130
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 132
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 132
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 135
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 135
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 139
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 139
ERROR - 2023-01-22 13:44:06 --> Severity: Notice --> Undefined property: CI_Loader::$AnswerModel C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 140
ERROR - 2023-01-22 13:44:06 --> Severity: Error --> Call to a member function getVoteCount() on null C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 140
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 50
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 85
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 128
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 128
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 129
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 129
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 130
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 130
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 132
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 132
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 135
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 135
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 139
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 139
ERROR - 2023-01-22 13:44:46 --> Severity: Notice --> Undefined property: CI_Loader::$AnswerModel C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 140
ERROR - 2023-01-22 13:44:46 --> Severity: Error --> Call to a member function getVoteCount() on null C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 140
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:45:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 50
ERROR - 2023-01-22 13:45:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 85
ERROR - 2023-01-22 13:54:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:54:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:54:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:54:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 13:54:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 13:54:38 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:55:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-22 13:55:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 13:55:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-22 13:55:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 13:55:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 13:55:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 13:55:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 13:55:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 13:55:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 14:01:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:01:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:01:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:01:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 14:01:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 14:01:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 14:01:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-22 14:01:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:01:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:01:35 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 14:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 14:01:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 59
ERROR - 2023-01-22 14:01:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 94
ERROR - 2023-01-22 14:02:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:02:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:02:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 14:02:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 21
ERROR - 2023-01-22 14:02:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 59
ERROR - 2023-01-22 14:02:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 94
ERROR - 2023-01-22 14:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:04:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:11 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:04:12 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:04:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:04:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:04:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 14:04:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:04:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-22 14:04:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-22 14:04:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:04:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 14:04:54 --> Severity: Notice --> Undefined variable: upVote C:\xampp\htdocs\Serverside_coursework\application\models\AnswersModel.php 8
ERROR - 2023-01-22 14:04:54 --> Severity: Notice --> Undefined variable: downVote C:\xampp\htdocs\Serverside_coursework\application\models\AnswersModel.php 9
ERROR - 2023-01-22 14:04:54 --> Query error: Column 'down_Vote' cannot be null - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `up_Vote`, `down_Vote`) VALUES (NULL, 'test answer description', NULL, NULL)
ERROR - 2023-01-22 14:05:36 --> Query error: Column 'down_Vote' cannot be null - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `up_Vote`, `down_Vote`) VALUES (NULL, 'test answer description', NULL, NULL)
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:05:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:05:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 14:06:05 --> Query error: Column 'down_Vote' cannot be null - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `up_Vote`, `down_Vote`) VALUES (NULL, 'test answer description new', NULL, NULL)
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:06:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:06:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 14:07:01 --> Query error: Column 'down_Vote' cannot be null - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `up_Vote`, `down_Vote`) VALUES (NULL, 'test answer description new', NULL, NULL)
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:07:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 14:07:08 --> Query error: Column 'down_Vote' cannot be null - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `up_Vote`, `down_Vote`) VALUES (NULL, 'test answer description new', NULL, NULL)
ERROR - 2023-01-22 14:09:10 --> 404 Page Not Found: ViewAnswer/displayAnswers
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:09:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 14:09:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 19:21:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 19:21:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 19:21:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-22 19:21:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
