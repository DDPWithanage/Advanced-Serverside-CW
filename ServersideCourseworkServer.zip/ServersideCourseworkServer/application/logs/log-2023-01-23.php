<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:28:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:32:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:32:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:32:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:44:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:44:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:44:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:44:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:46:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:46:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:46:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:46:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 05:47:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 05:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 06:26:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 06:26:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:26:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:28:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 39
ERROR - 2023-01-23 06:29:25 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 39
ERROR - 2023-01-23 06:29:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 39
ERROR - 2023-01-23 06:32:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 40
ERROR - 2023-01-23 06:32:31 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 40
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 06:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 06:33:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:35:49 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:35:49 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:37:21 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:37:21 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:39:39 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:39:39 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:43:24 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:43:24 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:44:49 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:44:49 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:45:11 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:45:11 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:45:26 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:45:26 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 06:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 06:45:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 06:48:01 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 06:48:01 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:02:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:02:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:03:25 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 07:03:25 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:44:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:44:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:45:07 --> 404 Page Not Found: Css/login.css
ERROR - 2023-01-23 07:45:07 --> 404 Page Not Found: Images/login.jpg
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:45:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:45:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:47:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:47:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:47:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:47:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:48:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:48:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:48:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:48:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:48:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:48:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:48:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:48:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:48:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:48:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 07:48:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 07:48:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 07:48:59 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:49:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:49:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:49:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:49:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 07:49:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 07:49:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 07:49:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:49:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:49:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:49:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:49:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 07:49:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 07:49:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 07:49:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 07:49:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:50:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 07:50:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:50:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:50:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:50:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:50:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:50:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:50:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:50:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 07:50:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 07:50:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 07:50:48 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 07:59:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 07:59:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:00:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:00:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:00:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:01:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 08:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 08:03:38 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 08:03:38 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:03:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:03:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:03:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 08:03:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 08:03:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 08:03:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:03:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:03:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:03:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 08:03:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 08:03:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 08:03:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 08:03:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:48 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 08:03:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:03:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:03:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 08:03:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 08:03:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:04:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:04:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:04:28 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '11'
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:04:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:14:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:14:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:24:52 --> Query error: Table 'coursework.user' doesn't exist - Invalid query: SELECT `user_Id`
FROM `user`
WHERE `user_EmailAddress` = 'kavee@gmail.com'
ERROR - 2023-01-23 08:25:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:25:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:54:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:54:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:54:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:54:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:54:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:54:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:54:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:54:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:54:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:54:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:55:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:55:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:55:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 08:55:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 08:55:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 08:55:03 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 08:55:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 08:55:17 --> 404 Page Not Found: ViewAnswer/displayAnswers
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 08:55:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:56:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 08:56:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 08:56:50 --> 404 Page Not Found: ViewAnswer/displayAnswers
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 08:59:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 08:59:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:59:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:59:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:59:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:59:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:59:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:59:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:59:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:59:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:59:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 08:59:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 08:59:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:59:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 08:59:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 08:59:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 08:59:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 08:59:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 08:59:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 08:59:58 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 09:00:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 09:00:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 09:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 09:00:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 09:00:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 09:00:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 09:00:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 09:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 09:09:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 09:09:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 09:09:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 09:09:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 09:09:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 09:09:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 09:09:57 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 09:45:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 09:45:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 09:45:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 09:45:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 09:45:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 09:45:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 09:45:29 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 11:52:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 11:52:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:52:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 11:52:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 11:52:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 11:52:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 11:52:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 11:52:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 11:52:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:52:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:52:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 11:52:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 11:52:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 11:52:58 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 11:54:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 11:54:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:54:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 11:54:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 11:54:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 11:54:10 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 11:54:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 11:54:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:54:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 11:54:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 11:54:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 11:54:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 11:54:52 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:03:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:03:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:03:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:03:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:03:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:03:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:03:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:03:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:15:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:15:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:15:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:15:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:15:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:16:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:16:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:16:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:16:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:16:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:17:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:17:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:17:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:17:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 7
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:17:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:52:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:52:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 12:52:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 12:52:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 12:52:51 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:52:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:52:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:52:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:52:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 12:52:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 12:52:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 12:52:55 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 12:52:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:53:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:53:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:53:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:53:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:53:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:53:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 12:53:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 12:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 12:53:27 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:53:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:53:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:53:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:54:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:54:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:54:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 12:54:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 12:54:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 12:54:10 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:55:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:55:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:55:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:55:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 12:56:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-23 12:56:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 107
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:56:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:56:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 12:56:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:56:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 12:57:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:57:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:57:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:57:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 12:57:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 12:57:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 12:57:43 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:57:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 12:57:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 12:59:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 12:59:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 12:59:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 12:59:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 12:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:02:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 13:02:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 13:02:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 49
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 49
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 13:02:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:02:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 13:44:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:44:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:44:30 --> Severity: Notice --> Undefined variable: ids C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:44:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:44:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 65
ERROR - 2023-01-23 13:44:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:44:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 91
ERROR - 2023-01-23 13:44:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 13:45:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:45:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:45:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:45:40 --> Severity: Notice --> Undefined variable: ids C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:45:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:45:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 65
ERROR - 2023-01-23 13:45:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:45:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 91
ERROR - 2023-01-23 13:45:40 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 13:45:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:45:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:45:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:45:41 --> Severity: Notice --> Undefined variable: ids C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:45:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:45:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 65
ERROR - 2023-01-23 13:45:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:45:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 91
ERROR - 2023-01-23 13:45:41 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 13:46:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:46:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:46:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:46:34 --> Severity: Notice --> Undefined variable: ids C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:46:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:46:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 65
ERROR - 2023-01-23 13:46:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:46:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 91
ERROR - 2023-01-23 13:46:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:47:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 13:47:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 13:47:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 13:56:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:56:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:56:41 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:56:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:56:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 65
ERROR - 2023-01-23 13:56:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:56:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 91
ERROR - 2023-01-23 13:56:41 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 13:57:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 13:57:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 13:57:10 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:57:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2023-01-23 13:57:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 65
ERROR - 2023-01-23 13:57:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 13:57:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 91
ERROR - 2023-01-23 13:57:10 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 62
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 82
ERROR - 2023-01-23 14:09:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 14:09:04 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 62
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 82
ERROR - 2023-01-23 14:09:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 14:09:21 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:09:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 62
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 82
ERROR - 2023-01-23 14:09:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 14:09:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:10:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:10:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 62
ERROR - 2023-01-23 14:10:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 82
ERROR - 2023-01-23 14:10:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 14:10:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 14:10:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:10:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:10:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:10:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 62
ERROR - 2023-01-23 14:10:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 82
ERROR - 2023-01-23 14:10:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 14:10:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 33
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 49
ERROR - 2023-01-23 14:10:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 84
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 14:11:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:11:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:11:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:11:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:11:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 63
ERROR - 2023-01-23 14:11:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-23 14:11:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 14:11:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:12:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:12:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:12:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:12:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 63
ERROR - 2023-01-23 14:12:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-23 14:12:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 14:12:29 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 14:12:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:12:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:12:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:12:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:12:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 63
ERROR - 2023-01-23 14:12:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-23 14:12:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 14:12:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:13:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:13:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:13:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:13:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 63
ERROR - 2023-01-23 14:13:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-23 14:13:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 14:13:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:14:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:14:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:14:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:14:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 62
ERROR - 2023-01-23 14:14:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 82
ERROR - 2023-01-23 14:14:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 14:14:07 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 14:20:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:20:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:21:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:21:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:21:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:21:01 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:21:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-23 14:21:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2023-01-23 14:21:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 87
ERROR - 2023-01-23 14:21:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 14:21:01 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:23:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:23:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:23:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:23:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2023-01-23 14:23:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 87
ERROR - 2023-01-23 14:23:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 14:23:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:48:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:48:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:48:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:48:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2023-01-23 14:48:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 87
ERROR - 2023-01-23 14:48:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 14:48:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 14:48:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:48:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:48:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:48:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:48:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:48:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2023-01-23 14:48:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 87
ERROR - 2023-01-23 14:48:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 14:48:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 14:49:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:49:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 14:49:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:49:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:49:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:49:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 14:49:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 14:49:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 14:49:58 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 14:49:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 14:49:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 14:49:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 14:49:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 77
ERROR - 2023-01-23 15:33:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:33:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:33:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:33:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:33:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:33:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:33:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:33:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:33:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:33:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:33:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:33:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:33:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:33:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:33:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:33:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:33:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:33:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:34:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:34:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:34:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:34:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:34:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:34:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:34:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:34:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:34:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:34:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:34:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:34:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:34:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:34:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:34:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:34:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:34:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:34:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:37:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:37:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:37:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:37:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:37:27 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:37:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:37:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:37:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:37:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:37:48 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:37:50 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:37:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:37:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:37:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:37:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:37:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:37:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:37:52 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:38:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:38:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:38:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:38:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:38:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:38:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:38:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:38:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:38:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:38:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:38:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:38:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:38:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:39:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:39:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:39:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:39:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:39:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:39:42 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2023-01-23 15:40:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:40:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:40:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:40:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:40:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:40:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:40:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:40:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:40:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:40:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:40:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:40:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:40:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:40:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:40:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:40:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:40:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:40:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:40:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:40:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:40:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:41:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:41:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:41:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:41:05 --> Severity: Warning --> Missing argument 1 for ViewAnswers::displayAnswers() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 21
ERROR - 2023-01-23 15:41:05 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 24
ERROR - 2023-01-23 15:41:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:41:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:41:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:46:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:46:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:46:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:46:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:46:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:46:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:46:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:46:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:46:53 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:46:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:46:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:46:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:46:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:47:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:47:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:47:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:47:40 --> Severity: Warning --> Missing argument 1 for ViewAnswers::displayAnswers() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 21
ERROR - 2023-01-23 15:47:40 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 24
ERROR - 2023-01-23 15:47:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:47:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:47:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:48:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:48:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:48:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:48:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:48:20 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:49:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:49:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:49:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:49:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:49:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:50:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:50:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:50:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:50:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:50:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:50:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:50:51 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:50:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:50:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:50:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:50:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:50:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:50:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:50:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:50:55 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:50:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:50:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:50:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:50:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:51:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:51:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:51:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:51:26 --> Severity: Warning --> Missing argument 1 for ViewAnswers::displayAnswers() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 21
ERROR - 2023-01-23 15:51:26 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 24
ERROR - 2023-01-23 15:51:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:51:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:51:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:53:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:53:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:53:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:53:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:53:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:53:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:53:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:53:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:53:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:53:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:53:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 15:53:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:53:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 15:53:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:53:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:53:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:53:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:53:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 15:53:52 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 15:58:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:58:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:58:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 15:58:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 15:59:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 15:59:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 15:59:14 --> Severity: Warning --> Missing argument 1 for ViewAnswers::displayAnswers() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 21
ERROR - 2023-01-23 15:59:14 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 24
ERROR - 2023-01-23 15:59:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 15:59:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 15:59:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 16:02:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:02:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:02:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:02:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:02:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:02:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:02:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:02:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:02:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:02:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:02:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:02:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 16:02:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 16:03:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:03:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:03:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:03:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 16:03:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:03:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 16:03:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:04:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:04:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:04:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:04:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:04:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 16:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 16:04:31 --> 404 Page Not Found: 1/index
ERROR - 2023-01-23 16:05:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:05:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:05:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:05:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 16:05:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 16:06:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:06:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:06:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:06:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:06:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:06:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:06:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-23 16:09:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-23 16:09:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-23 16:12:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:12:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:12:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:12:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:12:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:12:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:12:52 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:13:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:13:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:13:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:13:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:13:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:13:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:13:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:13:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:13:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:13:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:13:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:13:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:13:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:14:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:14:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:14:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:14:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:14:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:14:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:14:25 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:14:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:14:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:14:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:14:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-23 16:14:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-23 16:14:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-23 16:14:27 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:16:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:16:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:16:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:16:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:16:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:16:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:16:02 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:16:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:16:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:16:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:16:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:16:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:16:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:16:44 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:17:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:17:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:17:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:17:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:17:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:17:44 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:17:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:17:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:17:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 80
ERROR - 2023-01-23 16:17:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:17:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:17:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:17:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:17:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:17:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:17:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:17:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:18:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:18:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:18:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:18:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:18:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:18:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:18:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 80
ERROR - 2023-01-23 16:18:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:18:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:18:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:18:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:18:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:18:20 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:18:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:18:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 80
ERROR - 2023-01-23 16:18:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:18:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:18:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:18:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:18:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:18:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:18:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:18:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:18:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:18:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:18:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:18:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:18:41 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:19:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:19:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:19:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:19:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:19:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:19:29 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:19:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:19:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:19:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 80
ERROR - 2023-01-23 16:19:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:21:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:21:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:21:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:21:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 66
ERROR - 2023-01-23 16:21:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 86
ERROR - 2023-01-23 16:21:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 16:21:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:26:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:26:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:26:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:26:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:26:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:26:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:26:22 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:26:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:26:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:26:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:26:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:26:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:26:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:26:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:27:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:27:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:27:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:27:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:27:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:27:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:27:04 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:27:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:27:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:27:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:27:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:27:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:27:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:27:28 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:40:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:40:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:40:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:40:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:40:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:40:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:40:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:40:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:40:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:40:24 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:40:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:40:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:40:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:40:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:40:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:40:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:40:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:40:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 16:40:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 16:40:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 16:40:45 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:41:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:41:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:41:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:41:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2023-01-23 16:41:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 87
ERROR - 2023-01-23 16:41:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 16:41:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 16:41:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:41:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:41:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:41:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 80
ERROR - 2023-01-23 16:41:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:41:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 16:43:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:43:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:43:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:43:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:43:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:46:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:46:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:46:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:46:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:46:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:46:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:56:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:56:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:56:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:56:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:56:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:56:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:56:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:56:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:56:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:56:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:56:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:56:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:57:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:57:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:57:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:57:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:57:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:59:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:59:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:59:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:59:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:59:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:59:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 16:59:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 16:59:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-23 16:59:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 16:59:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 102
ERROR - 2023-01-23 17:00:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:00:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:00:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:00:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-23 17:00:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-23 17:00:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-23 17:00:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:00:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:00:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-23 17:00:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-23 17:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-23 17:01:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:01:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:01:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:01:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-23 17:01:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-23 17:01:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-23 17:02:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:02:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:02:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:02:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 90
ERROR - 2023-01-23 17:02:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 17:02:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 17:03:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:03:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:03:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:03:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 90
ERROR - 2023-01-23 17:03:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 17:03:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 17:04:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:04:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:04:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:04:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:04:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:04:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:05:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:05:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:05:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:05:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:05:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:05:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:05:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:05:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:05:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:05:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:05:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:05:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:06:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:06:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:06:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:06:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:06:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:06:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:07:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:07:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:07:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:07:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:07:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:07:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:07:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:07:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:07:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:07:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:08:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:08:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:08:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 91
ERROR - 2023-01-23 17:08:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 17:08:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:08:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:08:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:08:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:08:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:08:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:09:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:09:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:09:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:09:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:09:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:09:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:09:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:09:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:09:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:09:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:09:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:10:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:10:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:10:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:10:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:10:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:10:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:10:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:10:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 17:10:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 17:10:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:10:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:10:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:10:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:10:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:11:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:11:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:11:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:11:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:11:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:11:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:11:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:11:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:11:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:11:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:12:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:12:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:12:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:12:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:12:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:12:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:12:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:12:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:12:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:14:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:14:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:14:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:14:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2023-01-23 17:14:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2023-01-23 17:14:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 17:14:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:14:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:14:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:14:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:14:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:14:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:15:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:15:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:15:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 75
ERROR - 2023-01-23 17:15:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 17:15:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 101
ERROR - 2023-01-23 17:15:04 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:15:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:15:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:15:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:15:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 75
ERROR - 2023-01-23 17:15:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 17:15:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 101
ERROR - 2023-01-23 17:15:07 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:15:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:15:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:15:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:15:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 75
ERROR - 2023-01-23 17:15:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 17:15:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 101
ERROR - 2023-01-23 17:15:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:16:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:16:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 76
ERROR - 2023-01-23 17:16:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-23 17:16:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 102
ERROR - 2023-01-23 17:16:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:16:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:16:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:16:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:16:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:16:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:16:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 76
ERROR - 2023-01-23 17:16:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-23 17:16:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 102
ERROR - 2023-01-23 17:16:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:16:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:16:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:16:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 76
ERROR - 2023-01-23 17:16:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-23 17:16:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 102
ERROR - 2023-01-23 17:16:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 17:47:58 --> 404 Page Not Found: HelpViewphp/index
ERROR - 2023-01-23 17:51:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 17:51:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 17:51:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 17:51:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 17:51:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:08:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:08:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:08:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:08:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:08:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined property: stdClass::$upVote C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 56
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined property: stdClass::$downVote C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined property: stdClass::$upVote C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 56
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined property: stdClass::$downVote C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined property: stdClass::$upVote C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 56
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined property: stdClass::$downVote C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:08:38 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:08:38 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:09:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:09:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:09:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:09:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:09:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:09:28 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:09:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:09:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:09:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:09:33 --> Severity: error --> Exception: Unable to locate the model you have specified: AnswerModel C:\xampp\htdocs\Serverside_coursework\system\core\Loader.php 349
ERROR - 2023-01-23 21:10:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:10:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:10:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:10:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:10:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:10:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:10:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:10:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:10:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:10:45 --> Severity: Error --> Call to undefined method AnswersModel::upVoteAnswer() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 41
ERROR - 2023-01-23 21:11:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:11:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:11:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:11:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:11:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:11:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:11:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:11:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:11:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:11:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:11:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:11:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:11:47 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 42
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:11:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:11:49 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:12:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:12:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:12:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:12:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:12:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:12:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 42
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:12:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:12:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:12:55 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:13:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:13:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:13:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:13:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 42
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:13:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:13:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:13:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 42
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:13:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:13:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:13:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:13:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:13:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:13:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:13:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:13:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:13:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:13:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:13:25 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 51
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:13:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:13:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:13:30 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:17:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:17:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:17:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:17:35 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 50
ERROR - 2023-01-23 21:17:35 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:17:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:17:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:17:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:17:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:17:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:17:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 50
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:17:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:17:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:17:58 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:20:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:20:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:20:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:20:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:20:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:20:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:20:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:20:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:20:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:20:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:20:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:20:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:20:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:20:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:20:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:20:18 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:20:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:20:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:20:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:20:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:20:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:23:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:23:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:23:06 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:23:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:23:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:23:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:23:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:23:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:23:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:23:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:23:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:23:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:23:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:23:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:23:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:23:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:23:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:23:24 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:24:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:24:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:24:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:24:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:24:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:24:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:24:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:24:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 50
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:24:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:24:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:24:21 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:26:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:26:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:26:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:26:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:26:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:26:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:26:44 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:26:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:26:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:26:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:26:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:26:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:26:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:26:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:26:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:26:48 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined property: ViewAnswers::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 50
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:26:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:26:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:26:50 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:26:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:26:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:26:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:26:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:26:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:27:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:27:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:27:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:27:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:27:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:29:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:29:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:29:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:29:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:29:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:29:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:29:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:29:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:29:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:29:49 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:29:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:29:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:29:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:29:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:29:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:29:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:30:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:30:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:30:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:30:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:30:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:30:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:30:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:30:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:30:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:30:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:30:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:30:10 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:30:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:30:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:30:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:30:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:30:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-23 21:30:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-23 21:30:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:30:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:30:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:31:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:31:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:31:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:31:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:31:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:31:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:31:22 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:31:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:31:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:31:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:31:22 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:34:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:34:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:34:13 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:34:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:34:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:34:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:34:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:34:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:34:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:34:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:34:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:34:28 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:34:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:34:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:34:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:34:28 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:34:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:34:59 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:34:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:34:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:34:59 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:36:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:36:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:16 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:36:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:36:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:36:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:36:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:36:17 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:36:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:36:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:36:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:36:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:36:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:36:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:22 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:36:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:36:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:36:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:36:23 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:36:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:36:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:36:55 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:36:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:36:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:36:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:36:55 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:37:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:37:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:37:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:37:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:37:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:38:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:38:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:38:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:38:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:38:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:38:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:38:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:38:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:38:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:38:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:38:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:38:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:38:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:38:32 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:38:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:38:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:38:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:38:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:39:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:40:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:40:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:15 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:40:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:40:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:40:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:40:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:40:15 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:40:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:40:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:40:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:40:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:40:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:40:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:21 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:40:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:40:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:40:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:40:22 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:40:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:40:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:40:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:40:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:40:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:53 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:40:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:40:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:40:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:40:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:40:53 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:40:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:40:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:40:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:40:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:41:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:41:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:41:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:41:00 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:41:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:41:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:41:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:41:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:41:00 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:42:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:42:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:42:41 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:42:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:42:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:42:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:42:41 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:43:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:43:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 77
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 77
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 104
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 104
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:43:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:43:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:43:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:44:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:44:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:44:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:44:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:44:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:44:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:44:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:44:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:44:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:44:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:44:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:44:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:44:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:44:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:44:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:19 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:44:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:44:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:44:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:44:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:44:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:44:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:44:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:46:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:46:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:46:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:46:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:46:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:15 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:46:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:46:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:46:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:46:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:46:15 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 105
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:46:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:47:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:47:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:47:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:21 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:47:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:47:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:47:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:47:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:47:21 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:47:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:47:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:47:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:47:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:47:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:47:44 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:47:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 41
ERROR - 2023-01-23 21:47:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 21:47:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 21:47:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 21:47:45 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 21:48:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 76
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 103
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 21:48:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 21:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:00:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:00:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:00:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 22:00:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:00:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:00:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:00:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:00:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:02:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:02:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:02:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:02:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 22:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 77
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 77
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 104
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 104
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 22:04:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:04:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 22:04:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 77
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 77
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 104
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 104
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 22:04:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:04:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:05:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 22:05:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:05:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:05:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:05:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:05:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:05:28 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:05:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:30 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:05:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 92
ERROR - 2023-01-23 22:05:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:05:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:05:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:05:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:05:49 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:05:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:05:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:05:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 22:05:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 22:18:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:18:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:18:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:18:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 22:18:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:18:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:18:23 --> 404 Page Not Found: Answers/postanswer
ERROR - 2023-01-23 22:18:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:18:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:18:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:18:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 22:18:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:18:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:21:19 --> 404 Page Not Found: Answers/postanswer
ERROR - 2023-01-23 22:22:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:22:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 22:22:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:22:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:22:11 --> 404 Page Not Found: PostAnswers/5
ERROR - 2023-01-23 22:22:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:22:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 22:22:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:22:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:22:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:22:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:22:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:22:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:22:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:22:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 22:22:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 22:22:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:22:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:22:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:22:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:22:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:23:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:23:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:23:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 97
ERROR - 2023-01-23 22:23:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-23 22:23:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:23:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:23:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 22:23:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 22:25:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:25:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:25:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:25:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 100
ERROR - 2023-01-23 22:25:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 117
ERROR - 2023-01-23 22:25:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 117
ERROR - 2023-01-23 22:25:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:25:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:25:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:25:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 101
ERROR - 2023-01-23 22:25:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 118
ERROR - 2023-01-23 22:25:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 118
ERROR - 2023-01-23 22:26:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:26:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:26:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:26:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 101
ERROR - 2023-01-23 22:26:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 118
ERROR - 2023-01-23 22:26:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 118
ERROR - 2023-01-23 22:27:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:27:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:27:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-23 22:27:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 121
ERROR - 2023-01-23 22:27:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 121
ERROR - 2023-01-23 22:28:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:28:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:28:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:28:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:28:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:28:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:28:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:28:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:28:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:28:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:29:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:29:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:29:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:29:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:29:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:29:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:29:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:29:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:29:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:29:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:29:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:29:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:29:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:30:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:30:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:30:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:30:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:30:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:30:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:30:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:30:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:30:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:30:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:31:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:31:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:31:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:31:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:31:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:32:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:32:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:32:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:32:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:35:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:35:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:35:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:35:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:35:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:35:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:35:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:35:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:35:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:35:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:35:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:36:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:36:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:36:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:36:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:36:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:36:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:36:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:36:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:36:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:36:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:38:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:38:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:38:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:38:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:38:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:38:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:38:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:38:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:38:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:39:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:39:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:39:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 110
ERROR - 2023-01-23 22:39:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-23 22:39:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-23 22:39:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:39:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:39:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 111
ERROR - 2023-01-23 22:39:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 128
ERROR - 2023-01-23 22:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 128
ERROR - 2023-01-23 22:39:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:39:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:39:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 111
ERROR - 2023-01-23 22:39:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 128
ERROR - 2023-01-23 22:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 128
ERROR - 2023-01-23 22:40:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:40:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:40:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 112
ERROR - 2023-01-23 22:40:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 129
ERROR - 2023-01-23 22:40:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 129
ERROR - 2023-01-23 22:40:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:40:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:40:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 110
ERROR - 2023-01-23 22:40:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-23 22:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 127
ERROR - 2023-01-23 22:41:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:41:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:41:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:41:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:41:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:41:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:41:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:41:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:41:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:42:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:42:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:42:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:42:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:42:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 108
ERROR - 2023-01-23 22:42:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:42:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 125
ERROR - 2023-01-23 22:42:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:42:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:42:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:42:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:42:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 109
ERROR - 2023-01-23 22:42:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 126
ERROR - 2023-01-23 22:43:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:43:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:43:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:43:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:43:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:44:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:44:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:44:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:44:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:44:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:44:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:44:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:44:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:44:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:44:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:45:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:45:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:45:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:45:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:45:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:45:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:46:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:46:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:46:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:46:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:46:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:46:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:46:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:46:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:46:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:46:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:46:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:46:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:46:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:46:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:46:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:46:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:46:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:47:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-23 22:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 75
ERROR - 2023-01-23 22:49:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:49:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:49:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 63
ERROR - 2023-01-23 22:49:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 96
ERROR - 2023-01-23 22:50:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:50:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:50:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 22:50:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:50:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 22:50:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:50:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:50:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:50:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:50:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:50:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:51:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:51:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:51:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:51:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:51:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:51:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:51:13 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:51:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:51:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:51:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:51:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 88
ERROR - 2023-01-23 22:51:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 108
ERROR - 2023-01-23 22:51:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:51:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:56:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:56:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:56:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 100
ERROR - 2023-01-23 22:56:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 120
ERROR - 2023-01-23 22:56:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 126
ERROR - 2023-01-23 22:56:23 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:56:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:56:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:56:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:56:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 22:56:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 113
ERROR - 2023-01-23 22:56:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 119
ERROR - 2023-01-23 22:56:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:57:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:57:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:57:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:57:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 22:57:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 112
ERROR - 2023-01-23 22:57:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 118
ERROR - 2023-01-23 22:57:07 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:57:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:57:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:57:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:57:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 94
ERROR - 2023-01-23 22:57:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:57:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 120
ERROR - 2023-01-23 22:57:57 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:58:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:58:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:58:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:58:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 94
ERROR - 2023-01-23 22:58:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:58:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 120
ERROR - 2023-01-23 22:58:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:58:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:58:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:58:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 94
ERROR - 2023-01-23 22:58:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 22:58:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 120
ERROR - 2023-01-23 22:58:29 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:59:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:59:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:59:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:59:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 22:59:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 112
ERROR - 2023-01-23 22:59:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 118
ERROR - 2023-01-23 22:59:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 22:59:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 22:59:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 22:59:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 93
ERROR - 2023-01-23 22:59:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 113
ERROR - 2023-01-23 22:59:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 119
ERROR - 2023-01-23 22:59:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:00:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:00:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:00:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 94
ERROR - 2023-01-23 23:00:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 114
ERROR - 2023-01-23 23:00:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 120
ERROR - 2023-01-23 23:00:20 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:00:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:00:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:00:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:00:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 23:00:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 112
ERROR - 2023-01-23 23:00:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 118
ERROR - 2023-01-23 23:00:48 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:01:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:01:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:01:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:01:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 23:01:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 112
ERROR - 2023-01-23 23:01:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 118
ERROR - 2023-01-23 23:01:56 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:02:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 92
ERROR - 2023-01-23 23:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 112
ERROR - 2023-01-23 23:02:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 118
ERROR - 2023-01-23 23:02:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:03:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:03:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:03:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:03:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:03:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:03:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:03:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:04:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:04:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:04:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:04:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:04:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:04:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:04:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:05:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:05:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:05:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:05:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:05:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:05:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:05:09 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:05:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:05:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:05:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:05:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:05:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:05:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:05:30 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:05:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:05:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:05:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:05:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:05:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:05:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:05:51 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:06:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:06:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:06:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:06:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:06:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:06:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:06:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:06:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:06:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:06:36 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:06:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:06:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:06:49 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:07:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:07:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:07:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:07:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:07:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:07:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:07:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:07:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:07:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:07:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:07:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:07:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:07:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:07:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:07:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:07:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:07:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:07:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:07:33 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:08:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:08:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:08:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:08:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:08:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:08:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:21:59 --> 404 Page Not Found: ViewAnswers/fetchAnswers
ERROR - 2023-01-23 23:22:00 --> 404 Page Not Found: ViewAnswers/fetchAnswers
ERROR - 2023-01-23 23:22:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:22:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:22:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:22:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:22:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:22:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:22:08 --> 404 Page Not Found: ViewAnswers/fetchAnswers
ERROR - 2023-01-23 23:23:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:23:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:23:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:23:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:23:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:24:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:24:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:24:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:24:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:24:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:24:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:24:33 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:24:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\editAnswers.php 22
ERROR - 2023-01-23 23:24:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editAnswers.php 22
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editAnswers.php 48
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editAnswers.php 48
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editAnswers.php 72
ERROR - 2023-01-23 23:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editAnswers.php 72
ERROR - 2023-01-23 23:24:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:26:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:26:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:26:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:26:03 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:27:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:27:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:27:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:27:20 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:27:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:27:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:27:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:27:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:27:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:27:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:27:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:27:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:27:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:27:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:28:00 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:29:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:29:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:29:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:29:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:29:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:29:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:29:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:29:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:29:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:29:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 63
ERROR - 2023-01-23 23:29:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 96
ERROR - 2023-01-23 23:29:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:29:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:29:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:29:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:29:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:30:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:30:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:30:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:30:09 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:30:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:30:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:30:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:30:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:30:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:30:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 63
ERROR - 2023-01-23 23:30:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 96
ERROR - 2023-01-23 23:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:30:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:38 --> Severity: Warning --> Missing argument 1 for ViewAnswers::displayAnswers() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 22
ERROR - 2023-01-23 23:30:38 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 25
ERROR - 2023-01-23 23:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:30:38 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:30:38 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:30:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:30:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:30:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:30:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:30:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:30:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:30:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:30:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:30:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:30:49 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:31:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:31:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:31:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:31:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:31:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:31:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 63
ERROR - 2023-01-23 23:31:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 96
ERROR - 2023-01-23 23:31:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:31:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:29 --> Severity: Warning --> Missing argument 1 for ViewAnswers::displayAnswers() C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 22
ERROR - 2023-01-23 23:31:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\ViewAnswers.php 25
ERROR - 2023-01-23 23:31:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:31:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:31:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:31:29 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:31:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:31:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:31:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:31:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:31:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:31:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:31:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:31:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:31:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:31:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:32:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:32:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:32:09 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:32:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:32:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:32:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:32:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-23 23:32:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 124
ERROR - 2023-01-23 23:32:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:32:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:32:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:32:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-23 23:32:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 115
ERROR - 2023-01-23 23:32:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 121
ERROR - 2023-01-23 23:32:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-23 23:33:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-23 23:33:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:33:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-23 23:33:46 --> 404 Page Not Found: Images/logo.jpg
