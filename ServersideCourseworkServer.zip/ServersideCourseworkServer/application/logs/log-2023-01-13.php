<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-13 05:58:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-13 05:58:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-13 05:58:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-13 09:41:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-13 09:41:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-13 09:41:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-13 14:20:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-13 14:20:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-13 14:20:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
