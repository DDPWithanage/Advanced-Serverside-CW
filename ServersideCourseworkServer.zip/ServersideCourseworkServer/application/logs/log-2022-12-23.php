<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-23 05:53:42 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2022-12-23 05:53:42 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2022-12-23 05:53:42 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2022-12-23 05:55:58 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2022-12-23 05:55:58 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2022-12-23 05:55:58 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2022-12-23 05:56:06 --> Query error: Table 'coursework.vote' doesn't exist - Invalid query: UPDATE `vote` SET vote = votes-1
WHERE `answer_Id` = '\n<div style='
ERROR - 2022-12-23 05:56:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-23 06:00:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2022-12-23 06:00:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2022-12-23 06:00:03 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2022-12-23 06:00:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2022-12-23 06:00:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2022-12-23 06:00:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2022-12-23 06:01:47 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2022-12-23 06:01:47 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2022-12-23 06:01:47 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2022-12-23 08:08:43 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2022-12-23 08:08:43 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2022-12-23 08:08:43 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 39
ERROR - 2022-12-23 08:10:11 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 08:10:11 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 08:10:11 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 08:10:28 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 08:10:28 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 08:10:28 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 08:13:18 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 08:13:18 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 08:13:18 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 08:15:02 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 08:15:02 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 08:15:02 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 08:15:13 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 08:15:13 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 08:15:13 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 08:15:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 08:15:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 08:15:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 09:31:17 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 09:31:17 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 09:31:17 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 09:31:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-23 09:33:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-23 09:35:30 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 09:35:30 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 09:35:30 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 09:36:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('3', 'answer description 3', NULL)
ERROR - 2022-12-23 09:36:10 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 09:36:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('3', 'answer description 3', NULL)
ERROR - 2022-12-23 09:36:35 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 09:36:35 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 09:36:35 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 09:36:44 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 09:36:44 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('3', 'answer description 3', NULL)
ERROR - 2022-12-23 09:37:14 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 09:38:54 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 09:38:54 --> 404 Page Not Found: ViewAnswers/loadData
ERROR - 2022-12-23 10:03:08 --> 404 Page Not Found: ViewAnswers/loadData
ERROR - 2022-12-23 10:04:44 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 10:04:44 --> 404 Page Not Found: ViewAnswers/loadData
ERROR - 2022-12-23 10:06:05 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 10:06:05 --> 404 Page Not Found: ViewAnswers/loadData
ERROR - 2022-12-23 10:06:08 --> 404 Page Not Found: ViewAnswers/loadData
ERROR - 2022-12-23 10:07:03 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 10:07:03 --> 404 Page Not Found: ViewAnswers/loadAnswers
ERROR - 2022-12-23 11:37:22 --> 404 Page Not Found: PostAnswers/vote
ERROR - 2022-12-23 11:37:22 --> 404 Page Not Found: ViewAnswers/loadAnswers
ERROR - 2022-12-23 14:46:54 --> 404 Page Not Found: ViewAnswers/loadAnswers
ERROR - 2022-12-23 14:47:43 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-23 14:47:43 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-23 14:47:43 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-23 14:49:46 --> 404 Page Not Found: ViewAnswers/loadAnswers
