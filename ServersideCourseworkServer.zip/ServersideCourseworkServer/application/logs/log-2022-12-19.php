<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-19 05:12:34 --> Query error: Unknown column 'username' in 'field list' - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES ('Malmi', 'malmi@gmail.com', 'malmi123')
ERROR - 2022-12-19 05:41:59 --> Query error: Unknown column 'username' in 'field list' - Invalid query: INSERT INTO `user` (`username`, `email`, `password`) VALUES ('Malmi', 'malmi@gmail.com', 'malmi123')
ERROR - 2022-12-19 06:11:58 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 17
ERROR - 2022-12-19 06:11:58 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 17
ERROR - 2022-12-19 06:11:58 --> Severity: Warning --> log() expects parameter 1 to be double, string given C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 17
ERROR - 2022-12-19 06:12:47 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:13:17 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:13:18 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:13:18 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:15:20 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:15:22 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:15:23 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:18:33 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:17 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:18 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:18 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:18 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:23 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:23 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:24 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:28:24 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:38 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:39 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:39 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:40 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:40 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:40 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:29:41 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:01 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:02 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:02 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:48:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:06 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:07 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:07 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:07 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:07 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:07 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:08 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:55:08 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:25 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:27 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:27 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:27 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:28 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:28 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:28 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:28 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:28 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:28 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:30 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:30 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:30 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:30 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:30 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:30 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:31 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:31 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 06:59:31 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:03:36 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:03:37 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:03:37 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:03:38 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:03:38 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:04:29 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:06:01 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:08:02 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:08:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:08:03 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:08:04 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:08:04 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\coursework_advancedserverside\application\controllers\login.php 16
ERROR - 2022-12-19 07:43:25 --> Query error: Table 'coursework.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` IS NULL
AND `password` IS NULL
ERROR - 2022-12-19 07:44:00 --> Query error: Table 'coursework.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` IS NULL
AND `password` IS NULL
ERROR - 2022-12-19 07:44:02 --> Query error: Table 'coursework.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` IS NULL
AND `password` IS NULL
ERROR - 2022-12-19 07:44:02 --> Query error: Table 'coursework.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `username` IS NULL
AND `password` IS NULL
ERROR - 2022-12-19 07:57:00 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\coursework_advancedserverside\application\controllers\Login.php 18
ERROR - 2022-12-19 07:57:00 --> Query error: Table 'userdb.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` IS NULL
AND `email` IS NULL
AND `password` IS NULL
ERROR - 2022-12-19 07:57:29 --> Query error: Table 'userdb.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` IS NULL
AND `password` IS NULL
ERROR - 2022-12-19 08:00:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 08:00:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 08:01:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 08:01:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 08:02:59 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:02:59 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:05:14 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:05:14 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:07:47 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:07:47 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:11:12 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 08:11:12 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 11:01:48 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 11:01:48 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 13:55:30 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 13:55:30 --> 404 Page Not Found: Login/assets
ERROR - 2022-12-19 16:00:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 16:00:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 16:38:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 16:38:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 16:39:19 --> Query error: Table 'userdb.user' doesn't exist - Invalid query: SELECT *
FROM `user`
ERROR - 2022-12-19 16:41:15 --> Query error: Unknown column 'User_Name' in 'field list' - Invalid query: INSERT INTO `users` (`User_Name`, `User_EmailAddress`, `User_Password`) VALUES ('Pavani', 'pavani@gmail.com', 'pavani123')
ERROR - 2022-12-19 16:41:43 --> Query error: Unknown column 'User_Name' in 'field list' - Invalid query: INSERT INTO `users` (`User_Name`, `User_EmailAddress`, `User_Password`) VALUES ('Pavani', 'pavani@gmail.com', 'pavani123')
ERROR - 2022-12-19 18:16:35 --> Query error: Table 'coursework.users' doesn't exist - Invalid query: SELECT *
FROM `users`
ERROR - 2022-12-19 18:19:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-12-19 18:19:05 --> 404 Page Not Found: Assets/js
