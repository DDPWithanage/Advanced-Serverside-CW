<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-03 12:08:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-03 12:08:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-03 12:08:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-03 12:10:06 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-03 12:10:06 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-03 12:10:06 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-03 12:27:57 --> Severity: Error --> Call to undefined method AuthModel::is_loggedin() C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 45
ERROR - 2023-01-03 12:29:40 --> Severity: Error --> Call to undefined method AuthModel::is_loggedin() C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 45
ERROR - 2023-01-03 12:29:44 --> Severity: Error --> Call to undefined method AuthModel::is_loggedin() C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 45
ERROR - 2023-01-03 12:30:04 --> Severity: Error --> Call to undefined method AuthModel::is_loggedin() C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 45
