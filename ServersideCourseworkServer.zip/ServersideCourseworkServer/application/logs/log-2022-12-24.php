<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-24 05:23:39 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 05:23:39 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 43
ERROR - 2022-12-24 05:23:39 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 45
ERROR - 2022-12-24 05:25:44 --> Query error: Table 'coursework.vote' doesn't exist - Invalid query: UPDATE `vote` SET vote = votes+1
WHERE `answer_Id` = '\n<div style='
ERROR - 2022-12-24 05:25:44 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-24 05:41:00 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 05:41:00 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 05:41:00 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 06:14:22 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 06:14:22 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 06:14:22 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 06:15:06 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:15:31 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:15:39 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:17:35 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:19:07 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:19:13 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:19:20 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:20:57 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 06:20:57 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 06:20:57 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 06:21:28 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:21:49 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:25:53 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:25:57 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:26:08 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:26:35 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2022-12-24 06:26:39 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:26:41 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:28:51 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:32:38 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:32:45 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:33:30 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:40:55 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 06:42:00 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 06:42:05 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 06:42:05 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 06:42:05 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 07:00:02 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-24 07:02:37 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:02:41 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('', '', NULL)
ERROR - 2022-12-24 07:07:23 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 07:07:23 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 07:07:23 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 07:08:10 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:08:54 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:12:31 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:17:30 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:17:32 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:17:46 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:17:53 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:23:51 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:33:39 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:47:53 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:49:35 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:49:40 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:51:38 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:53:06 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:53:10 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:53:15 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 07:55:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 07:55:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 07:56:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 07:56:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 08:42:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 08:49:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:03:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:03:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 09:03:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 09:03:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 09:04:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:09:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:10:28 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:10:36 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:12:32 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:04 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:09 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:11 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:12 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:12 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:12 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:13 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:13 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:15 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:28 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:30 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:30 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:31 --> 404 Page Not Found: ViewAnswers/index
ERROR - 2022-12-24 09:13:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:13:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:13:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 09:14:03 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 10:14:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 10:14:22 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 10:14:25 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 10:14:35 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 10:52:24 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 11:34:00 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 11:34:07 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 11:34:37 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 11:34:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 11:34:44 --> 404 Page Not Found: Question/index
ERROR - 2022-12-24 11:43:47 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2022-12-24 11:43:47 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2022-12-24 11:43:47 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2022-12-24 16:18:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 16:19:16 --> Severity: Warning --> Missing argument 1 for homeController::delete() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:19:16 --> Severity: Notice --> Undefined property: homeController::$recording_model C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:19:16 --> Severity: Error --> Call to a member function deleteQuestions() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:22:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:22:13 --> Severity: Warning --> Missing argument 1 for homeController::delete() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:22:13 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:25:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:25:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:25:40 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:25:40 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:26:58 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:26:58 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:27:03 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:03 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:03 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:03 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:27:16 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:16 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:16 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:16 --> Severity: Notice --> Use of undefined constant site_url - assumed 'site_url' C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2022-12-24 16:27:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:27:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:28:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:28:20 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:28:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:41:01 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:41:01 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:41:09 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:41:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:41:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:41:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:41:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:42:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:43:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:43:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:43:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:43:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:43:19 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:43:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:43:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 16:43:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 16:43:48 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:43:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:43:56 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:43:56 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:44:04 --> Severity: Warning --> Missing argument 1 for homeController::deleteRecords() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 23
ERROR - 2022-12-24 16:44:04 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 28
ERROR - 2022-12-24 16:44:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:44:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 95
ERROR - 2022-12-24 16:44:17 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question_Id` = '1'
ERROR - 2022-12-24 17:14:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 45
ERROR - 2022-12-24 17:39:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2022-12-24 17:55:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2022-12-24 17:55:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2022-12-24 17:55:20 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question_Id` = '1'
ERROR - 2022-12-24 17:55:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2022-12-24 17:55:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2022-12-24 17:55:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2022-12-24 17:55:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 67
ERROR - 2022-12-24 17:56:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:56:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:56:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:56:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:57:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:57:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:57:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:57:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:57:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:57:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:57:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:57:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:58:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:58:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:58:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:58:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:58:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:58:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:58:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:58:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:58:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:58:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:58:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:58:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:59:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:59:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:59:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:59:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 17:59:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 17:59:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:00:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:00:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:00:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:00:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:04:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:04:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:05:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:05:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 18:05:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 50
ERROR - 2022-12-24 18:05:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 19:23:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:23:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:29:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:29:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:29:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:29:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:30:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:30:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:30:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:30:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:34:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2022-12-24 19:34:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2022-12-24 19:48:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:48:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:48:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:48:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:48:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:48:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
ERROR - 2022-12-24 19:48:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 69
ERROR - 2022-12-24 19:48:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 89
