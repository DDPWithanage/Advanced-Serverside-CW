<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-14 06:55:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-14 06:58:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-14 06:59:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-14 06:59:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-14 07:23:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 07:24:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 115
ERROR - 2023-01-14 07:24:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 07:25:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 08:37:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 08:37:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 08:37:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 08:37:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 08:37:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 08:37:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 08:37:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 08:37:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 08:37:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 08:37:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 08:37:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-14 08:38:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 08:44:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:09:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:09:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:09:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 09:09:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 09:09:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_Id = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_Id = 2
ERROR - 2023-01-14 09:21:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:21:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:22:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 09:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 09:22:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_Id = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_Id = 2
ERROR - 2023-01-14 09:25:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:25:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:25:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 09:25:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-14 09:25:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_Id = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_Id = 2
ERROR - 2023-01-14 09:42:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:42:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:42:47 --> Severity: Error --> Call to a member function result() on string C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 49
ERROR - 2023-01-14 09:47:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:47:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:47:33 --> Severity: Error --> Call to undefined method HomeController::set_response() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 39
ERROR - 2023-01-14 09:47:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:47:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-14 09:47:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:47:58 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '11'
ERROR - 2023-01-14 09:48:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:48:03 --> Severity: Error --> Call to undefined method HomeController::set_response() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 39
ERROR - 2023-01-14 09:48:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:48:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:48:42 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '11'
ERROR - 2023-01-14 09:48:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:48:45 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-14 09:48:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:52:12 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 09:52:12 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 09:52:12 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 09:52:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:53:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 09:54:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 09:54:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 09:54:10 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 09:55:28 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 09:55:28 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 09:55:28 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 09:56:19 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 09:56:19 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 09:56:19 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 09:58:55 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 09:58:55 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 09:58:55 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 09:59:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:00:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:00:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 10:00:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 10:00:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 10:00:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:01:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 10:01:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 10:01:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 10:01:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:01:44 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:01:44 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:01:44 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:02:06 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('13', 'Answer description 13', NULL)
ERROR - 2023-01-14 10:02:48 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:02:48 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:02:48 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:03:01 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('13', 'Answer description 13', NULL)
ERROR - 2023-01-14 10:03:06 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:03:06 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:03:06 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:03:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:03:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 10:03:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 10:03:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 10:03:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:03:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 10:03:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 10:03:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 10:03:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:03:35 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:03:35 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:03:35 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:04:04 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('13', 'Answer Description 13', NULL)
ERROR - 2023-01-14 10:05:02 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:05:02 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:05:02 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:05:04 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: INSERT INTO `answer` (`question_Id`, `answer_Description`, `vote`) VALUES ('13', 'Answer Description 13', NULL)
ERROR - 2023-01-14 10:05:41 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:05:41 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:05:41 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:05:45 --> 404 Page Not Found: ViewAnswer/displayAnswers
ERROR - 2023-01-14 10:06:08 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:06:08 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:06:08 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:06:15 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2023-01-14 10:06:19 --> 404 Page Not Found: ViewAnswer/index
ERROR - 2023-01-14 10:06:20 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:06:20 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:06:20 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:06:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:06:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 10:06:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 10:06:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 10:06:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:07:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-14 10:07:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-14 10:07:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-14 10:07:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 10:07:09 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:07:09 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:07:09 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 10:07:27 --> 404 Page Not Found: ViewAnswer/display%20Answers
ERROR - 2023-01-14 10:07:30 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 10:07:30 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 10:07:30 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 13:46:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 13:46:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 41
ERROR - 2023-01-14 13:46:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 42
ERROR - 2023-01-14 13:46:36 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 44
ERROR - 2023-01-14 13:46:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:12:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:12:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:13:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:21:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:21:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:21:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:22:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:22:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:22:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:23:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:25:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:25:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:25:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:26:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:26:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:26:33 --> Severity: Warning --> Missing argument 1 for HomeController::search() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 51
ERROR - 2023-01-14 14:26:33 --> Severity: Notice --> Undefined property: HomeController::$users C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:26:33 --> Severity: Error --> Call to a member function is_logged_in() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:30:45 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 96
ERROR - 2023-01-14 14:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 96
ERROR - 2023-01-14 14:30:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:30:48 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 96
ERROR - 2023-01-14 14:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 96
ERROR - 2023-01-14 14:30:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:30:57 --> Severity: Warning --> Missing argument 1 for HomeController::search() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 51
ERROR - 2023-01-14 14:30:57 --> Severity: Notice --> Undefined property: HomeController::$users C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:30:57 --> Severity: Error --> Call to a member function is_logged_in() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:32:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:32:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:32:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:32:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:33:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:33:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:33:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:33:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:33:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:33:55 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:33:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:33:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:33:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:34:07 --> Severity: Warning --> Missing argument 1 for HomeController::search() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 51
ERROR - 2023-01-14 14:34:07 --> Severity: Notice --> Undefined property: HomeController::$users C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:34:07 --> Severity: Error --> Call to a member function is_logged_in() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:37:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:37:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:37:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:37:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:38:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:38:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:38:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:38:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:38:12 --> Severity: Notice --> Undefined property: HomeController::$users C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:38:12 --> Severity: Error --> Call to a member function is_logged_in() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:39:06 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:39:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:39:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:39:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:39:11 --> Severity: Error --> Call to undefined method AuthModel::is_logged_in() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 52
ERROR - 2023-01-14 14:39:32 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:39:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:39:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:39:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:39:37 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:39:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:39:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:39:42 --> Query error: Unknown column 'keyword' in 'where clause' - Invalid query: SELECT *
FROM `question`
WHERE `keyword` = 'question'
ERROR - 2023-01-14 14:47:29 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:47:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:47:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:47:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:47:31 --> Severity: Error --> Call to undefined method HomeController::set_response() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 56
ERROR - 2023-01-14 14:49:24 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:49:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:49:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:49:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:49:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:49:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:49:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:49:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:50:18 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:50:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:50:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:50:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:51:35 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 55
ERROR - 2023-01-14 14:52:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 14:52:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 14:52:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 14:59:45 --> Severity: Error --> Call to undefined method HomeController::set_response() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 57
ERROR - 2023-01-14 16:01:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 16:01:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 16:01:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 16:01:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 16:01:30 --> Severity: Error --> Call to undefined method HomeController::set_response() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 57
ERROR - 2023-01-14 18:30:38 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 18:30:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 67
ERROR - 2023-01-14 18:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 97
ERROR - 2023-01-14 18:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 114
ERROR - 2023-01-14 18:30:41 --> Severity: Error --> Call to undefined function alert() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 57
