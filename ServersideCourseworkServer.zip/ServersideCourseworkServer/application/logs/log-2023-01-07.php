<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-07 06:44:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-07 06:44:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-07 06:44:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 95
ERROR - 2023-01-07 06:57:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-07 06:57:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-07 06:57:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-07 06:57:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-07 06:57:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-07 06:57:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-07 06:57:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-07 06:57:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-07 06:57:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-07 07:00:30 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:00:30 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:00:30 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:00:30 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:00:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:02:47 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:47 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:47 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:47 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:02:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:06:08 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:06:08 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:06:08 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:06:08 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:06:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:08:52 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:08:52 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:08:52 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:08:52 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:08:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:09:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:09:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:09:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:09:50 --> Severity: Notice --> Undefined property: stdClass::$quesion_Id C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 56
ERROR - 2023-01-07 07:09:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:14:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:14:23 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question_Id` = '11'
ERROR - 2023-01-07 07:24:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:24:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-07 07:24:08 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`coursework`.`answer`, CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`question_Id`) REFERENCES `question` (`question_Id`)) - Invalid query: DELETE FROM `question`
WHERE `question`.`question_Id` = '11'
ERROR - 2023-01-07 08:11:29 --> Severity: Warning --> Missing argument 2 for QuestionsModel::deleteQuestions(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php on line 27 and defined C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 39
ERROR - 2023-01-07 08:11:29 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-07 08:11:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-07 08:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-07 08:11:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 11' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 11
ERROR - 2023-01-07 09:23:26 --> Severity: Warning --> Missing argument 2 for QuestionsModel::deleteQuestions(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php on line 27 and defined C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 39
ERROR - 2023-01-07 09:23:26 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-07 09:23:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-07 09:23:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-07 09:23:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 11' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 11
