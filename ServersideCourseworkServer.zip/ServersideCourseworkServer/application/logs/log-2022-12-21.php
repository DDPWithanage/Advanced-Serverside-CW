<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-21 11:52:09 --> Severity: Error --> Call to undefined method signUpModel::displayUsers() C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 14
ERROR - 2022-12-21 11:53:59 --> Severity: Notice --> Undefined property: signUp::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 15
ERROR - 2022-12-21 12:34:57 --> Severity: Notice --> Undefined property: signUp::$form_validation C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:34:57 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:39:29 --> Severity: Notice --> Undefined property: signUp::$form_validation C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:39:29 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:40:21 --> Severity: Notice --> Undefined property: signUp::$form_validation C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 24
ERROR - 2022-12-21 12:40:21 --> Severity: Error --> Call to a member function run() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 24
ERROR - 2022-12-21 12:41:38 --> Severity: Notice --> Undefined property: signUp::$form_validation C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:41:38 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:42:13 --> Severity: Notice --> Undefined property: signUp::$form_validation C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:42:13 --> Severity: Error --> Call to a member function set_rules() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 20
ERROR - 2022-12-21 12:45:37 --> Severity: Notice --> Undefined property: signUp::$signup_model C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 34
ERROR - 2022-12-21 12:45:37 --> Severity: Error --> Call to a member function insertUsers() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php 34
ERROR - 2022-12-21 12:46:39 --> Query error: Column 'user_Name' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `user_emailaddress`, `user_password`) VALUES (NULL, NULL, '$2y$10$zc3jmEOhO89c5P7q91RMZ.g5Gm86X6bwyofVDbRzYvulwOP6otzXq')
ERROR - 2022-12-21 13:13:52 --> Severity: Warning --> Missing argument 1 for signUpModel::insertUsers(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\signUp.php on line 34 and defined C:\xampp\htdocs\Serverside_coursework\application\models\signUpModel.php 5
ERROR - 2022-12-21 13:13:52 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\Serverside_coursework\application\models\signUpModel.php 16
ERROR - 2022-12-21 13:13:52 --> Severity: Warning --> log() expects parameter 1 to be double, array given C:\xampp\htdocs\Serverside_coursework\application\models\signUpModel.php 16
ERROR - 2022-12-21 13:13:52 --> Query error: Column 'user_Name' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `user_emailaddress`, `user_password`) VALUES (NULL, NULL, '$2y$10$h6s7slLnaOBSTNnuIagKQub7pj454.e1UUd4r8Gj8nqrX2cPwtgoC')
ERROR - 2022-12-21 13:14:57 --> Severity: Notice --> Use of undefined constant console - assumed 'console' C:\xampp\htdocs\Serverside_coursework\application\models\signUpModel.php 16
ERROR - 2022-12-21 13:14:57 --> Severity: Warning --> log() expects parameter 1 to be double, array given C:\xampp\htdocs\Serverside_coursework\application\models\signUpModel.php 16
ERROR - 2022-12-21 13:14:57 --> Query error: Column 'user_Name' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `user_emailaddress`, `user_password`) VALUES (NULL, NULL, '$2y$10$EL3oP7VyXlYg.Aro5D0kLe17DLgmDIrV6gukiEj.HXGPykxSXdzoO')
ERROR - 2022-12-21 13:15:41 --> Query error: Column 'user_Name' cannot be null - Invalid query: INSERT INTO `user` (`user_name`, `user_emailaddress`, `user_password`) VALUES (NULL, NULL, '$2y$10$KK58cP9ncVmjJ.DCuZJG9uOrzJShYmAmSC3EDcmrhGtzxCQ2HrWYq')
ERROR - 2022-12-21 14:08:42 --> Severity: Notice --> Undefined property: Login::$signUpModel C:\xampp\htdocs\Serverside_coursework\application\controllers\login.php 34
ERROR - 2022-12-21 14:08:42 --> Severity: Error --> Call to a member function getUsers() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\login.php 34
ERROR - 2022-12-21 15:13:06 --> 404 Page Not Found: HomeController/index
ERROR - 2022-12-21 15:13:25 --> 404 Page Not Found: HomeController/index
ERROR - 2022-12-21 15:40:58 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:40:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:48:55 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:48:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:49:53 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 30
ERROR - 2022-12-21 15:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 30
ERROR - 2022-12-21 15:51:35 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:51:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:56:13 --> 404 Page Not Found: HomeController/index
ERROR - 2022-12-21 15:57:07 --> 404 Page Not Found: HomeController/index
ERROR - 2022-12-21 15:57:11 --> 404 Page Not Found: HomeController/index
ERROR - 2022-12-21 15:57:14 --> 404 Page Not Found: HomeController/index
ERROR - 2022-12-21 15:58:09 --> Severity: Error --> Call to undefined function loadData() C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 12
ERROR - 2022-12-21 15:58:29 --> Severity: Notice --> Use of undefined constant loadData - assumed 'loadData' C:\xampp\htdocs\Serverside_coursework\application\controllers\homeController.php 12
ERROR - 2022-12-21 15:58:29 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 15:58:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 16:00:03 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 16:00:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 16:00:06 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 16:00:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 31
ERROR - 2022-12-21 16:28:35 --> Severity: Notice --> Undefined property: postQuestions::$data C:\xampp\htdocs\Serverside_coursework\application\controllers\postQuestions.php 14
ERROR - 2022-12-21 16:34:24 --> Severity: Warning --> Missing argument 4 for questionsModel::insertQuestions(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\postQuestions.php on line 24 and defined C:\xampp\htdocs\Serverside_coursework\application\models\questionsModel.php 5
ERROR - 2022-12-21 16:34:24 --> Severity: Notice --> Undefined variable: question_Description C:\xampp\htdocs\Serverside_coursework\application\models\questionsModel.php 9
ERROR - 2022-12-21 16:34:24 --> Query error: Duplicate entry '1' for key 'PRIMARY' - Invalid query: INSERT INTO `question` (`question_Id`, `user_Id`, `question_Title`, `question_Description`) VALUES ('1', 'test title 5', 'test description 5', NULL)
ERROR - 2022-12-21 18:22:28 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: INSERT INTO `question` (`user_Id`, `question_Title`, `question_Description`) VALUES ('1', 'test title 5', 'test description 5')
ERROR - 2022-12-21 19:09:37 --> Severity: Notice --> Undefined property: Login::$session C:\xampp\htdocs\Serverside_coursework\application\controllers\login.php 27
ERROR - 2022-12-21 19:09:37 --> Severity: Error --> Call to a member function set_userdata() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\login.php 27
ERROR - 2022-12-21 20:17:26 --> 404 Page Not Found: Price/index
ERROR - 2022-12-21 20:17:32 --> 404 Page Not Found: Disable/index
ERROR - 2022-12-21 20:17:43 --> 404 Page Not Found: Disable/index
ERROR - 2022-12-21 20:20:55 --> 404 Page Not Found: Price/index
ERROR - 2022-12-21 20:45:44 --> 404 Page Not Found: Price/index
