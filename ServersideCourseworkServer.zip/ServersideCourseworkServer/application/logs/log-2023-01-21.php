<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 03:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 03:55:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 03:55:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 03:55:07 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 03:59:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 03:59:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 03:59:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 03:59:30 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 03:59:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 03:59:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 03:59:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 03:59:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:01:13 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:01:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:01:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:01:13 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:01:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:01:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:01:14 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:01:40 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:02:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:02:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:02:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:02:47 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:03:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:03:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:03:07 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:03:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:03:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:03:47 --> 404 Page Not Found: Css/sidebar.css
ERROR - 2023-01-21 04:03:47 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:04:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:04:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:04:09 --> 404 Page Not Found: Css/sidebar.css
ERROR - 2023-01-21 04:04:09 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:04:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:04:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:04:12 --> 404 Page Not Found: Css/sidebar.css
ERROR - 2023-01-21 04:04:12 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:04:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:04:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:04:54 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:05:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:05:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:05:40 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:06:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:06:07 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:06:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:06:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:06:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:06:51 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:07:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:07:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:07:22 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:07:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:07:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:09:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:25 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:09:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:09:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:27 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:09:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:27 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:09:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:09:29 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:10:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:10:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:10:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:10:31 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:03 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:04 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:05 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:13 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:14 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:14 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:38 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:39 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:40 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:49 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:50 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:50 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:11:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:11:51 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:24 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:31 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:32 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:39 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:12:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:12:47 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:13:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:02 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:13:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:17 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:18 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:13:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:13:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:13:19 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:14:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:14:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:14:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:14:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:14:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:14:47 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:16:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 04:16:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:16:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 04:16:49 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:40:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:40:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:40:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:40:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:41:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:41:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:41:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:41:18 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:41:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:41:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:41:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:41:42 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:41:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:41:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:42:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:42:22 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:42:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:42:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:42:23 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:53:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:53:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:53:32 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:53:41 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:54:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:54:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:54:16 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:55:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:55:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:55:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:55:35 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:55:42 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:56:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:56:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:56:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:56:48 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:58:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:58:05 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:58:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:58:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:58:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:58:07 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 06:58:13 --> 404 Page Not Found: Questions/index
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:58:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 06:58:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 06:58:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:00:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:00:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:00:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:00:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:00:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:01:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:01:02 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:01:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:01:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:01:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:01:19 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:01:30 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:02:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:02:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:02:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:02:29 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:03:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:03:55 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:03:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:03:55 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:03:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:03:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:03:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:03:58 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:04:03 --> 404 Page Not Found: ViewQuestions/index
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:04:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:04:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:07:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:07:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:07:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:07:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:07:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:07:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:07:35 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:08:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:08:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:08:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:08:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:08:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:08:08 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:08:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:08:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:08:09 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:09:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:17 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:09:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:19 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:09:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:20 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:09:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:39 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:09:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:09:41 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:23:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:23:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:23:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:24:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:24:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:24:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:24:52 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 64
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 84
ERROR - 2023-01-21 07:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 84
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:25:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:25:46 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:29:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:29:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:29:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:29:07 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:30:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:30:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:30:40 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:32:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:32:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:32:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:32:58 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-21 07:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:33:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:33:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:33:29 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 62
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-21 07:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 82
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:34:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:34:31 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 65
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 85
ERROR - 2023-01-21 07:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 85
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:35:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:35:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:35:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:35:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:35:44 --> 404 Page Not Found: Css/header.css
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:35:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:35:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:35:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:36:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:36:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:36:07 --> 404 Page Not Found: Css/header.css
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:36:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:36:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:36:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:37:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:37:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:37:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:37:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:37:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 07:37:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 07:37:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:37:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:37:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:37:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:37:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:37:30 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:42:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 07:42:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-21 07:42:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 78
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:51:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 07:51:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 07:51:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:01:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:01:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:02:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:02:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:02:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:02:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:02:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:02:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 08:02:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 08:02:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:03:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:03:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 08:03:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 08:03:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 08:03:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 08:03:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 08:03:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:03:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:03:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:03:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:03:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:03:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:03:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:03:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 34
ERROR - 2023-01-21 08:03:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:05:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:05:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:05:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:05:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 23
ERROR - 2023-01-21 08:05:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:06:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:06:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:06:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:06:19 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 23
ERROR - 2023-01-21 08:06:19 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:06:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:06:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:06:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:06:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:06:43 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:07:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:07:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:07:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:07:12 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:16:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:16:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:16:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 08:16:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 08:16:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:16:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:16:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:16:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:16:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:16:50 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:18:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:10 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:18:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 08:18:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 08:18:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:18:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:18:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 08:18:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 08:18:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:18:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:18:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:18:54 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:18:54 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 08:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-21 08:19:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:20:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:20:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:20:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:31:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:31:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:31:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:31:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:31:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:31:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:31:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:31:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:31:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:32:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 08:32:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-21 08:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-21 08:33:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:33:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:33:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:33:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:33:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:33:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:33:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:33:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:33:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:33:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:33:40 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 08:39:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:39:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 08:39:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:39:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:39:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:39:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 08:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 08:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 09:00:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:00:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:00:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:00:58 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 24
ERROR - 2023-01-21 09:00:58 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:01:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:01:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:01:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:01:11 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:01:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:01:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:01:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:01:51 --> Severity: Notice --> Undefined property: stdClass::$useremail C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 24
ERROR - 2023-01-21 09:01:51 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:02:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:02:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:02:18 --> Severity: Notice --> Undefined property: stdClass::$useremail C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 24
ERROR - 2023-01-21 09:02:18 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:03:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:03:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:03:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:03:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 09:03:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:03:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:03:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:03:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:03:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:03:50 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 09:04:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-21 09:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 80
ERROR - 2023-01-21 09:04:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:04:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:40 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 09:04:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:04:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:04:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:04:44 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 56
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 09:05:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 09:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 09:05:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:05:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:05:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:05:25 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 09:19:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 09:19:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:41:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 09:41:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:41:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 09:41:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:41:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:41:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:41:36 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 09:44:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 09:44:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 09:44:41 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 09:44:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 09:44:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 09:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 09:44:42 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 09:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:03:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:03:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:03:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:03:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:03:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:04:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:04:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 54
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 10:04:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 81
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:07:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:07:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:07:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:07:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:07:57 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:08:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:08:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 55
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 82
ERROR - 2023-01-21 10:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 82
ERROR - 2023-01-21 10:12:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:12:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:12:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:12:57 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:15:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:16:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:16:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:16:01 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:16:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 56
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 56
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 83
ERROR - 2023-01-21 10:16:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 83
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:17:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:17:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 56
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 56
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 83
ERROR - 2023-01-21 10:17:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 83
ERROR - 2023-01-21 10:18:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:18:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:18:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:19:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Undefined variable: questions C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:19:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 22
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 56
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 56
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 83
ERROR - 2023-01-21 10:19:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\editQuestions.php 83
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:20:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:20:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:20:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:20:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:20:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:20:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:20:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 10:21:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:21:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:21:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:21:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:21:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:22:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:22:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:22:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:26:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 10:26:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 10:26:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 11:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 11:45:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 11:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:29:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:29:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:29:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:29:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:30:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:30:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:32:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:32:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:32:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:32:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:32:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:33:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:02 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:33:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:33:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:33:03 --> 404 Page Not Found: Css/homePage.css
ERROR - 2023-01-21 12:33:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:33:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:33:16 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:33:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:33:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:34:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:34:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:34:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:34:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:34:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:36:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:36:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:37:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:37:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:37:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:38:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:38:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:38:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:38:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:39:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:39:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:39:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:40:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:40:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:40:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:40:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:40:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:40:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:40:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:40:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:41:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:41:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:44:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:44:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:44:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:44:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:44:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:44:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:44:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:48:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:48:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:48:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:48:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:48:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:48:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:53:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:53:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:53:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:53:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:53:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:53:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:53:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:53:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:53:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:53:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 12:54:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 12:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 13:15:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 85
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 129
ERROR - 2023-01-21 13:15:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 146
ERROR - 2023-01-21 13:15:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 146
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 13:53:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:53:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 13:53:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 13:53:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 13:56:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 13:56:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 13:56:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 13:56:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 13:56:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 13:56:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 14:00:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:00:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 14:00:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 14:00:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 14:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:02:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 14:02:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 14:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 14:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 14:03:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 14:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 17:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 17:05:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 17:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 17:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 17:17:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 17:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 18:54:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 18:54:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 18:54:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 18:54:48 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:16:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:16:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:16:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:16:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:16:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:16:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:16:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:16:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:16:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:16:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:16:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:16:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:16:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:16:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:18:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:18:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:18:10 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-21 20:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-21 20:18:11 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-21 20:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-21 20:18:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 52
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:28:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:28:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:28:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:29:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:29:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:29:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:29:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:45:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:45:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:45:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:45:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:45:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:45:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:45:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:45:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:45:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:45:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:45:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:45:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:45:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:46:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:46:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:46:02 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-21 20:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-21 20:46:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 60
ERROR - 2023-01-21 20:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:47:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:47:14 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-21 20:47:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 24
ERROR - 2023-01-21 20:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 60
ERROR - 2023-01-21 20:54:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:54:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:34 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:54:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 59
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:54:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:54:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:54:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:54:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:54:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:54:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:54:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:54:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:54:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 20:54:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 20:54:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:54:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:54:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:54:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:54:56 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:54:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:54:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 59
ERROR - 2023-01-21 20:55:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:55:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:26 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:55:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:55:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 59
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:55:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:55:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:55:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:32 --> Severity: Notice --> Undefined variable: answers C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:55:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 23
ERROR - 2023-01-21 20:55:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 59
ERROR - 2023-01-21 20:55:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:55:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:55:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 20:55:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 20:55:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 20:55:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 20:55:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:59:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-21 20:59:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 86
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 20:59:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:59:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:59:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-21 20:59:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 86
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-21 21:02:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 21:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-21 21:02:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-21 21:02:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-21 21:02:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-21 21:04:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 55
ERROR - 2023-01-21 21:04:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 75
ERROR - 2023-01-21 21:04:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 81
ERROR - 2023-01-21 21:04:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 55
ERROR - 2023-01-21 21:04:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 75
ERROR - 2023-01-21 21:04:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 81
ERROR - 2023-01-21 21:06:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:06:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:06:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:06:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:06:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:06:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:06:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:06:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:06:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:06:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:06:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:07:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:07:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:07:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:19:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-21 21:19:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 86
ERROR - 2023-01-21 21:23:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2023-01-21 21:23:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:23:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:23:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:23:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:23:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:23:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:25:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:25:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:25:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:25:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:25:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:25:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:25:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:25:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:25:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:26:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:26:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:26:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:26:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:26:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:26:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:26:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:26:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:26:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-21 21:26:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:26:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:26:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:26:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:26:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:26:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:26:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:26:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-21 21:26:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:26:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:28:24 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2023-01-21 21:28:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 47
ERROR - 2023-01-21 21:28:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:28:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:28:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:30:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:30:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-21 21:30:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:30:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:30:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:30:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:30:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:30:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-21 21:30:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 86
ERROR - 2023-01-21 21:30:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:30:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 87
ERROR - 2023-01-21 21:30:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:30:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 104
ERROR - 2023-01-21 21:31:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:31:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:31:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:31:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:31:54 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:31:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:31:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:31:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:31:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:32:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:32:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:32:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:32:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:32:26 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 21:32:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:32:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:32:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:32:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:32:28 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 21:32:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:32:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:40 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 21:32:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:32:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:32:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 57
ERROR - 2023-01-21 21:32:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 77
ERROR - 2023-01-21 21:32:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 83
ERROR - 2023-01-21 21:57:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:57:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:57:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:57:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 59
ERROR - 2023-01-21 21:57:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 79
ERROR - 2023-01-21 21:57:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 85
ERROR - 2023-01-21 21:57:40 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:57:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 35
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 37
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 51
ERROR - 2023-01-21 21:57:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 86
