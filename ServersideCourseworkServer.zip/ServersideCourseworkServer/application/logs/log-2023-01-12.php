<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-12 18:44:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:44:42 --> Severity: Warning --> Missing argument 2 for QuestionsModel::deleteQuestions(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php on line 27 and defined C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 39
ERROR - 2023-01-12 18:44:42 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:44:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:44:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 18:46:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:46:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 18:46:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 18:46:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 18:47:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 18:47:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 18:47:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 18:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 18:47:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 18:47:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 18:47:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:47:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 18:47:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 18:47:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 18:47:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:47:25 --> Severity: Warning --> Missing argument 2 for QuestionsModel::deleteQuestions(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php on line 27 and defined C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 39
ERROR - 2023-01-12 18:47:25 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:47:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:47:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:47:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 18:47:29 --> Severity: Warning --> Missing argument 2 for QuestionsModel::deleteQuestions(), called in C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php on line 27 and defined C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 39
ERROR - 2023-01-12 18:47:29 --> Severity: Notice --> Undefined variable: username C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:47:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:47:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 18:47:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 18:59:27 --> Severity: Notice --> Undefined property: HomeController::$AuthModel C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 35
ERROR - 2023-01-12 18:59:27 --> Severity: Error --> Call to a member function is_loggedin() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 35
ERROR - 2023-01-12 18:59:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:59:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:59:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 18:59:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 18:59:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 18:59:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 18:59:36 --> Severity: Notice --> Undefined property: HomeController::$AuthModel C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 35
ERROR - 2023-01-12 18:59:36 --> Severity: Error --> Call to a member function is_loggedin() on null C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 35
ERROR - 2023-01-12 19:00:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:00:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:00:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:00:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:00:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:00:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:00:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 19:13:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:13:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:13:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:13:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:13:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:13:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:16:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:16:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:16:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 19:17:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:27:01 --> Severity: Error --> Call to undefined method HomeController::set_response() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 46
ERROR - 2023-01-12 19:27:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:27:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 19:27:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:27:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:27:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:27:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 19:29:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:29:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 19:29:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:29:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 9' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 9
ERROR - 2023-01-12 19:29:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:29:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 10' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 10
ERROR - 2023-01-12 19:29:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:29:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\models\QuestionsModel.php 40
ERROR - 2023-01-12 19:29:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND question_ID = 2' at line 1 - Invalid query: DELETE FROM question WHERE user_Id =  AND question_ID = 2
ERROR - 2023-01-12 19:29:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:38:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:38:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:38:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:41:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:41:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:41:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:41:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:41:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:41:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:41:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:41:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:41:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:41:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:41:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:41:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:42:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:42:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
ERROR - 2023-01-12 19:42:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 107
ERROR - 2023-01-12 19:42:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 70
ERROR - 2023-01-12 19:42:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 90
ERROR - 2023-01-12 19:42:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 96
