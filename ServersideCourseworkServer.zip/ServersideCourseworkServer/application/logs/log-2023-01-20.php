<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-20 11:20:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:20:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:20:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:20:38 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:20:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:43:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:43:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:43:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:43:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:43:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:45:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:45:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:45:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:45:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:45:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:45:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:45:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:45:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:45:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:46:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:46:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:46:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:46:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:46:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:46:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:46:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:46:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:46:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:46:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:46:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:47:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:47:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:47:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:47:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:47:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:47:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:47:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:47:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:47:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:47:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:47:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:30 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:48:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:48:56 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:48:56 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:48:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:51:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:51:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:51:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:51:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:51:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:51:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:51:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:51:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:51:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:51:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:51:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:51:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:51:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:51:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:51:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:51:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:55:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:55:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:55:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:55:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:55:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:55:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:55:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 11:56:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:56:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:56:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:56:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:56:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:56:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:56:04 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 11:56:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:56:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:56:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:56:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:56:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:56:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 11:56:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:56:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:56:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:56:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:56:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:56:19 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 11:57:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:57:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:57:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:57:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:57:24 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:57:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:57:24 --> 404 Page Not Found: Css/homePage.css
ERROR - 2023-01-20 11:57:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:57:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:57:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:57:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:57:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:58:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:58:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:58:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:58:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:58:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:58:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:58:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:58:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:58:28 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:58:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:58:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:58:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:58:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:58:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:58:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:58:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:59:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:59:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:59:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:59:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:59:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:59:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 11:59:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:59:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 11:59:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 11:59:26 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 11:59:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:00:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:00:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:00:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:00:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:00:35 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:00:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:00:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:00:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:00:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:00:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:00:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:02:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:02:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:02:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:02:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:02:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:02:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:02:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:02:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:02:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:03:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:03:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:03:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:03:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:03:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:03:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:03:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:03:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:03:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:03:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:05:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:05:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:05:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:05:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:05:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:45 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:05:45 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:05:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:05:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:05:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:06:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:06:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:06:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:06:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:06:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:09:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:09:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:09:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:09:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:09:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:09:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:09:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:09:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:09:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:09:27 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:09:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:09:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:09:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:09:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:09:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:10:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:10:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:10:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:10:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:10:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:11:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:11:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:11:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:11:08 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:11:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:11:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:11:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:11:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:11:39 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:11:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:11:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:11:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:11:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:11:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:11:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:14:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:14:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:14:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:14:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:16:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:16:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:16:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:16:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:16:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:16:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:16:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:16:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:16:43 --> 404 Page Not Found: Css/answersView.css
ERROR - 2023-01-20 12:16:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:16:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:16:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:16:57 --> 404 Page Not Found: ViewAnswers/css
ERROR - 2023-01-20 12:16:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:16:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:16:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:16:59 --> 404 Page Not Found: ViewAnswers/css
ERROR - 2023-01-20 12:16:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:16:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:16:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:16:59 --> 404 Page Not Found: ViewAnswers/css
ERROR - 2023-01-20 12:17:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:17:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:17:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:17:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:17:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:17:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:17:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:17:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:17:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:17:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:17:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:17:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:18:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:18:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:07 --> 404 Page Not Found: ViewAnswers/css
ERROR - 2023-01-20 12:18:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:18:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:18:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:08 --> 404 Page Not Found: ViewAnswers/css
ERROR - 2023-01-20 12:18:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:18:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:18:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:17 --> 404 Page Not Found: Css/answersView.css
ERROR - 2023-01-20 12:18:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:18:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:18:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:18 --> 404 Page Not Found: Css/answersView.css
ERROR - 2023-01-20 12:18:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:18:27 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:18:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:18:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:18:52 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:18:52 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:18:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:18:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 12:18:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 12:18:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 12:18:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:18:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:18:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:18:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:18:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 34
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 36
ERROR - 2023-01-20 12:19:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\postAnswersView.php 52
ERROR - 2023-01-20 12:19:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:19:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:19:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:19:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:19:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 12:19:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 12:19:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 12:19:25 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 12:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 15:58:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 15:58:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 15:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 15:58:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 15:58:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 15:58:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 15:59:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 15:59:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 15:59:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 15:59:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 15:59:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 15:59:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 15:59:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 15:59:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 15:59:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 15:59:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 15:59:53 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 15:59:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:00:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:00:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:00:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:00:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:00:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:00:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:00:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:00:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:00:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:00:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:00:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:00:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:00:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:00:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:00:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:02:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:02:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:47 --> 404 Page Not Found: Css/header.css
ERROR - 2023-01-20 16:02:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:02:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:02:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:48 --> 404 Page Not Found: Css/header.css
ERROR - 2023-01-20 16:02:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:02:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:02:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:50 --> 404 Page Not Found: Css/header.css
ERROR - 2023-01-20 16:02:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:02:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:02:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:02:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:02:51 --> 404 Page Not Found: Css/header.css
ERROR - 2023-01-20 16:03:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:03:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:03:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:01 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:03:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:03:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:03:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:02 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:03:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:03:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:17 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:31 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:31 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:32 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:32 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 57
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 77
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:04:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:04:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:05:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:05:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:05:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:05:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:05:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:05:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:05:11 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:05:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:05:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:05:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:05:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:05:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:05:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:06:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:06:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:06:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:06:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:06:05 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:06:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:06:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:06:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:06:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:06:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:06:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:06:58 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:06:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:06:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:06:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:06:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:06:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:06:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:06:59 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:07:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:07:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:07:00 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:00 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:07:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:07:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:07:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:40 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:42 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:07:42 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:07:42 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:08:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:08:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:08:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:08:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:08:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:08:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:08:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:08:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:08:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:08:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:08:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:08:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:09:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:09:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:09:41 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:42 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:09:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:09:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:09:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:09:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:09:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:09:44 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:12:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:12:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:12:46 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:12:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:12:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:12:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:12:46 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:12:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:12:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:12:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:12:47 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:12:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:12:47 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:13:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:13:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:13:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:10 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:13:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:13:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:13:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:11 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:12 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:12 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:13:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:13:12 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:14:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:14:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:14:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:14:12 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:14:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:14:12 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:15:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:15:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:15:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:15:02 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:15:02 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:15:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:15:03 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:16:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:16:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:16:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:16:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:16:05 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:16:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:16:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:16:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:17:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:17:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:17:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:17:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:17:01 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:17:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:17:01 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:17:10 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:18:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-20 16:18:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:18:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:18:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:18:46 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:18:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:18:46 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:19:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-20 16:19:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:19:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:19:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:19:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:19:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:19:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-20 16:19:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:19:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:19:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:19:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:19:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:19:18 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:20:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 61
ERROR - 2023-01-20 16:20:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:20:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 81
ERROR - 2023-01-20 16:20:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:20:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:20:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:20:36 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:21:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 60
ERROR - 2023-01-20 16:21:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:21:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 80
ERROR - 2023-01-20 16:21:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:21:29 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:21:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:21:29 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:22:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:22:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:22:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:22:09 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:22:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:22:09 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:30:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:30:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:30:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:30:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:30:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:30:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:30:20 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 16:30:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 16:30:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 16:31:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:31:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:31:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:31:19 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:31:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:32:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 16:32:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 16:32:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 16:50:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:50:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:50:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:50:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:50:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:50:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:50:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `answer`
JOIN `question` ON `answer`.`question_Id`=`question`.`question_Id`' at line 2 - Invalid query: SELECT *, count(question.question_Id) from answer
FROM `answer`
JOIN `question` ON `answer`.`question_Id`=`question`.`question_Id`
WHERE `question`.`question_Id` = '10'
ERROR - 2023-01-20 16:51:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 16:51:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 16:51:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 88
ERROR - 2023-01-20 16:51:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 105
ERROR - 2023-01-20 16:51:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 16:51:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 16:51:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 18:21:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 18:21:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 18:21:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 18:21:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:21:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:21:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:21:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:21:14 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:21:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:21:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:21:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:21:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:21:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:21:16 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:56:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:56:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:56:10 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:56:10 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:56:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:56:10 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:56:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:56:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:56:13 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:56:13 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:56:13 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:57:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:57:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:57:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:11 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:57:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:57:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:57:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:57:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:57:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:57:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:20 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 18:57:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 18:57:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 18:57:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 18:57:23 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 18:57:23 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:03:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:03:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:03:59 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:03:59 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:03:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:03:59 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:04:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:04:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:04:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:04:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:04:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:04:11 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:05:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:05:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:05:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:05:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:05:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:05:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:05:48 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:14:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:14:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:14:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:14:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:14:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:14:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:14:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:14:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:14:37 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:14:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:14:37 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:18:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 19:18:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 19:18:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 19:18:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:18:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:18:11 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:18:11 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:18:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 52
ERROR - 2023-01-20 19:18:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 72
ERROR - 2023-01-20 19:18:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\Serverside_coursework\application\views\answersView.php 78
ERROR - 2023-01-20 19:18:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:18:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:18:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:18:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:18:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:19:45 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\system\database\DB_query_builder.php 2443
ERROR - 2023-01-20 19:19:45 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `user_EmailAddress` = 'niki@gmail.com'
AND 0 = Array
ERROR - 2023-01-20 19:25:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\system\database\DB_query_builder.php 2443
ERROR - 2023-01-20 19:25:56 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `user_EmailAddress` = 'gayali@gmail.com'
AND 0 = Array
ERROR - 2023-01-20 19:30:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\system\database\DB_query_builder.php 2443
ERROR - 2023-01-20 19:30:09 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `user_EmailAddress` = 'gayali@gmail.com'
AND 0 = Array
ERROR - 2023-01-20 19:32:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:32:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:32:36 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:32:36 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:32:36 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 19:33:33 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\Serverside_coursework\system\database\DB_query_builder.php 2443
ERROR - 2023-01-20 19:33:33 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `user`
WHERE `user_EmailAddress` = 'gayali@gmail.com'
AND 0 = Array
ERROR - 2023-01-20 19:34:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 19:34:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:34:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 19:34:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 86
ERROR - 2023-01-20 19:34:43 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:34:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 103
ERROR - 2023-01-20 19:34:43 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:05 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:05 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:07 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:08 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:40 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:40 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:40 --> 404 Page Not Found: Css/sidebar.css
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:48 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:49 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:49 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:57 --> 404 Page Not Found: Css/sidebar.css
ERROR - 2023-01-20 21:06:57 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:06:58 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:06:58 --> 404 Page Not Found: Css/sidebar.css
ERROR - 2023-01-20 21:06:58 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:08:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:08:14 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:08:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:08:14 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:08:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:08:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:10:18 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:10:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:10:18 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:12:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:12:50 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:12:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:12:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:12:51 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:12:51 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:12:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:12:51 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:13:22 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:13:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:13:22 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:14:20 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:14:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:14:20 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:14:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:14:21 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:14:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:14:21 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:15:15 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:15 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:15:17 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:17 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:15:33 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:33 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:15:44 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:15:44 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:16:16 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:16 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:16:34 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:34 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:16:48 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:48 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:16:57 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:16:57 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:17:06 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:17:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:17:06 --> 404 Page Not Found: HomeController/css
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 58
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\components\header.php 78
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 45
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 89
ERROR - 2023-01-20 21:21:03 --> Severity: Notice --> Undefined variable: results C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:21:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 106
ERROR - 2023-01-20 21:21:03 --> 404 Page Not Found: HomeController/css
