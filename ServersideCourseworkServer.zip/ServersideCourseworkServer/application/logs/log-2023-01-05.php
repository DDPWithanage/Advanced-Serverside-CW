<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-05 13:53:47 --> 404 Page Not Found: Images/signup.jpg
ERROR - 2023-01-05 13:53:52 --> 404 Page Not Found: Images/signup.jpg
ERROR - 2023-01-05 13:53:56 --> 404 Page Not Found: Images/signup.jpg
