<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-04 18:37:58 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\Serverside_coursework\application\controllers\Login.php 62
ERROR - 2023-01-04 21:50:04 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:50:12 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:50:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:50:23 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:50:27 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:50:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:52:39 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:52:41 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:53:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 21:57:08 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:02:31 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:03:14 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:03:23 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:04:04 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:04:05 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:04:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:04:06 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:04:16 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:06:42 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:06:43 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:06:47 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:07:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:07:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:07:37 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:08:35 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:08:36 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:08:43 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:08:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:08:46 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:14:25 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:14:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:53 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:54 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:55 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:56 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:18:10 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:18:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:18:13 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:18:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:19:04 --> Severity: Error --> Call to undefined function loadData() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 13
ERROR - 2023-01-04 22:19:30 --> Severity: Error --> Call to undefined function loadData() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 13
ERROR - 2023-01-04 22:19:31 --> Severity: Error --> Call to undefined function loadData() C:\xampp\htdocs\Serverside_coursework\application\controllers\HomeController.php 13
ERROR - 2023-01-04 22:21:42 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:22:20 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:22:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:23:32 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:23:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:28:02 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:28:03 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:28:04 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:28:07 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:28:16 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:28:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:28:56 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:28:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:17 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:18 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:51 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:53 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:29:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:32:43 --> Severity: Notice --> Undefined variable: names C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Serverside_coursework\application\views\homePage.php 46
ERROR - 2023-01-04 22:34:22 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:34:25 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:34:25 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:34:29 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:34:34 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:34:49 --> 404 Page Not Found: Images/logo.jpg
ERROR - 2023-01-04 22:34:55 --> 404 Page Not Found: Images/logo.jpg
